/**
 * @fileoverview Manages actions and interactions for the Services Manager GUI.
 * Refactored for dual hosting (Electron + browser). No Node.js dependencies.
 *
 * @author Nguyen Huynh Tri Cuong
 * @version 2.0.0
 */

(function () {
  'use strict';

  const MM = window.MicroserviceManager;

  /************************************************************
   *                    Global Variables                      *
   ************************************************************/

  // Legacy globals — kept as dynamic aliases for backward compatibility.
  // They reflect the *currently active* broker (set on service click).
  MM.brokerUrl = 'localhost:5672';
  MM.routingKey = '';
  MM.servicesInfor = null;

  // Multi-broker data model
  MM.connections = {};       // { 'host:port': { brokerUrl, routingKey, services: {}, realtimeSubscribed } }
  MM.activeBrokerUrl = null; // set when user clicks a service item
  var serviceToBroker = {};  // { serviceName: 'host:port' } — reverse lookup

  const SERVICES_EXCHANGE_NAME = 'services_request';
  const SERVICES_GUI_FOLDER = 'services';
  const SERVICE_CONTENT_DIV = 'serviceContent';
  const SERVICE_LIST_DIV = 'servicesList';

  const DIV_NAME = {
    SERVICE_CONTENT_DIV: 'serviceContent',
    SERVICE_LIST_DIV: 'servicesList'
  };

  const CONNECTION_STATUS = {
    CONNECTED: 'connected',
    DISCONNECTED: 'disconnected'
  };

  const DEFAULT_GROUP = 'Other';

  // Internal services hidden from the sidebar.
  const HIDDEN_SERVICES = ['ServiceRegistry'];

  const IMAGE_PATH = {
    READY: 'img/ready.png',
    NOT_READY: 'img/not_ready.png',
    DISABLED: 'img/_not_ready.png',
    CONNECTED: 'img/connected.png',
    UNCONNECTED: 'img/unconnected.png'
  };

  var connectedStatus = false;
  var unloadFunction = null;
  var loginModal = null;
  var _servicePanels = {};     // { serviceName: HTMLElement }
  var _activePanelName = null; // name of the currently visible cached panel

  /**
   * Hides the active cached service panel, calls unloadFunction,
   * and removes any non-cached content (API explorer, placeholders).
   */
  function _deactivateCurrentPanel() {
    var contentDiv = document.getElementById(DIV_NAME.SERVICE_CONTENT_DIV);
    if (typeof unloadFunction === 'function') {
      unloadFunction();
      unloadFunction = null;
    }
    if (_activePanelName && _servicePanels[_activePanelName]) {
      var panel = _servicePanels[_activePanelName];
      var shellType = panel.getAttribute('data-shell-type');
      if (shellType === 'wasm' || shellType === 'qml' || shellType === 'widget') {
        // Canvas-based panels: use visibility:hidden instead of display:none
        // to keep non-zero dimensions. display:none makes canvas 0x0 which
        // crashes the WASM requestAnimationFrame loop (createImageData fails).
        // Anchor the absolute panel to fill its parent so it never collapses.
        // The original height (calc-based) is preserved — never overwritten.
        contentDiv.style.position = 'relative';
        panel.style.visibility = 'hidden';
        panel.style.position = 'absolute';
        panel.style.pointerEvents = 'none';
        panel.style.left = '0';
        panel.style.top = '0';
        panel.style.width = '100%';
      } else {
        panel.style.display = 'none';
      }
    }
    _activePanelName = null;
    // Remove non-cached children (API explorer, placeholders)
    Array.from(contentDiv.children).forEach(function (child) {
      if (!child.hasAttribute('data-cached-service')) {
        contentDiv.removeChild(child);
      }
    });
  }

  /************************************************************
   *               Multi-Broker Helper Functions               *
   ************************************************************/

  function addConnection(brokerUrl, routingKey) {
    MM.connections[brokerUrl] = {
      brokerUrl: brokerUrl,
      routingKey: routingKey,
      services: {},
      realtimeSubscribed: false
    };
  }

  function removeConnection(brokerUrl) {
    delete MM.connections[brokerUrl];
    rebuildMergedServicesInfor();
  }

  function rebuildMergedServicesInfor() {
    var merged = {};
    serviceToBroker = {};
    Object.keys(MM.connections).forEach(function (key) {
      var conn = MM.connections[key];
      Object.keys(conn.services).forEach(function (svcName) {
        merged[svcName] = conn.services[svcName];
        serviceToBroker[svcName] = key;
      });
    });
    // Preserve ServiceAlias (local-only, not from any broker)
    if (MM.servicesInfor && MM.servicesInfor.ServiceAlias) {
      merged.ServiceAlias = MM.servicesInfor.ServiceAlias;
    }
    MM.servicesInfor = merged;
  }

  function getConnectionCount() {
    return Object.keys(MM.connections).length;
  }

  function sanitizeBrokerId(brokerUrl) {
    return brokerUrl.replace(/[^a-zA-Z0-9]/g, '-');
  }

  /**
   * Resolve the broker URL for a given routing key.
   */
  function resolveBrokerUrl(routingKey) {
    // Check serviceToBroker for any service with matching routing_key
    var keys = Object.keys(serviceToBroker);
    for (var i = 0; i < keys.length; i++) {
      var svcName = keys[i];
      if (MM.servicesInfor[svcName] && MM.servicesInfor[svcName].routing_key === routingKey) {
        var brokerKey = serviceToBroker[svcName];
        if (MM.connections[brokerKey]) return brokerKey;
      }
    }
    // Check connections for matching registry routingKey
    var connKeys = Object.keys(MM.connections);
    for (var j = 0; j < connKeys.length; j++) {
      if (MM.connections[connKeys[j]].routingKey === routingKey) {
        return connKeys[j];
      }
    }
    // Fall back to active broker
    if (MM.activeBrokerUrl && MM.connections[MM.activeBrokerUrl]) return MM.activeBrokerUrl;
    // Fall back to first connection
    if (connKeys.length > 0) return connKeys[0];
    return null;
  }

  /**
   * Resolve the broker URL for a given service name.
   */
  function resolveBrokerUrlForService(serviceName) {
    if (serviceToBroker[serviceName] && MM.connections[serviceToBroker[serviceName]]) {
      return serviceToBroker[serviceName];
    }
    if (MM.activeBrokerUrl && MM.connections[MM.activeBrokerUrl]) return MM.activeBrokerUrl;
    var connKeys = Object.keys(MM.connections);
    if (connKeys.length > 0) return connKeys[0];
    return null;
  }

  /************************************************************
   *               Session Persistence                         *
   ************************************************************/

  function persistConnections() {
    try {
      var data = Object.keys(MM.connections).map(function (key) {
        var conn = MM.connections[key];
        return { brokerUrl: conn.brokerUrl, routingKey: conn.routingKey };
      });
      sessionStorage.setItem('mm_connections', JSON.stringify(data));
    } catch (e) { /* sessionStorage unavailable */ }
  }

  function loadPersistedConnections() {
    try {
      var raw = sessionStorage.getItem('mm_connections');
      if (raw) {
        return JSON.parse(raw);
      }
      // Legacy fallback
      var savedBrokerUrl = sessionStorage.getItem('mm_brokerUrl');
      var savedRoutingKey = sessionStorage.getItem('mm_routingKey');
      if (savedBrokerUrl) {
        return [{ brokerUrl: savedBrokerUrl, routingKey: savedRoutingKey || '' }];
      }
    } catch (e) { /* sessionStorage unavailable */ }
    return [];
  }

  /************************************************************
   *                    Toast Notifications                   *
   ************************************************************/

  /**
   * Show a Bootstrap toast notification.
   *
   * @param {string} title - Toast title.
   * @param {string} message - Toast message body.
   * @param {string} [type='info'] - Type: 'success', 'warning', 'danger', 'info'.
   */
  function showToast(title, message, type) {
    type = type || 'info';
    var bgClass = 'bg-' + type;
    var container = document.getElementById('toastContainer');

    var toastEl = document.createElement('div');
    toastEl.className = 'toast align-items-center text-white ' + bgClass + ' border-0';
    toastEl.setAttribute('role', 'alert');
    toastEl.setAttribute('aria-live', 'assertive');
    toastEl.setAttribute('aria-atomic', 'true');
    toastEl.innerHTML =
      '<div class="d-flex">' +
        '<div class="toast-body"><strong>' + _escapeHtml(title) + '</strong><br>' + _escapeHtml(message) + '</div>' +
        '<button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>' +
      '</div>';

    container.appendChild(toastEl);
    var toast = new bootstrap.Toast(toastEl, { autohide: true, delay: 4000 });
    toast.show();

    toastEl.addEventListener('hidden.bs.toast', function () {
      toastEl.remove();
    });
  }

  /**
   * Show a warning dialog (toast-based replacement for Electron dialog).
   *
   * @param {string} message - Warning message.
   */
  function showWarningDialog(message) {
    showToast('Warning', message, 'warning');
  }

  /**
   * Show a confirmation modal (Bootstrap-based replacement for native confirm()).
   * Native confirm() causes an Electron focus bug on Windows where all inputs
   * become unresponsive after the dialog is dismissed.
   *
   * @param {string} message - The confirmation message to display.
   * @param {Function} onConfirm - Callback invoked when the user clicks Confirm.
   */
  function showConfirm(message, onConfirm) {
    var modalEl = document.getElementById('confirmModal');
    var bodyEl = document.getElementById('confirmModalBody');
    var okBtn = document.getElementById('confirmModalOkBtn');
    bodyEl.textContent = message;

    var modal = bootstrap.Modal.getOrCreateInstance(modalEl);

    // Clone-replace OK button to remove old listeners
    var newOk = okBtn.cloneNode(true);
    okBtn.parentNode.replaceChild(newOk, okBtn);
    newOk.id = 'confirmModalOkBtn';

    newOk.onclick = function () {
      modal.hide();
      onConfirm();
    };

    modal.show();
  }

  /************************************************************
   *               Functions: GUI Element Handling             *
   ************************************************************/

  /**
   * Activates an HTML element by adding the 'active' CSS class to it.
   *
   * @param {HTMLElement} element - The HTML element to be activated.
   */
  function activateItem(element) {
    var buttons = document.querySelectorAll('.list-group-item');
    buttons.forEach(function (btn) { btn.classList.remove('active'); });
    element.classList.add('active');
  }

  /**
   * Removes all service items from the GUI list.
   */
  function clearServiceList() {
    var accordion = document.getElementById(DIV_NAME.SERVICE_LIST_DIV);
    while (accordion.firstChild) {
      accordion.removeChild(accordion.firstChild);
    }
  }

  /**
   * Removes service content GUI.
   */
  function clearServiceContent() {
    var contentService = document.getElementById(DIV_NAME.SERVICE_CONTENT_DIV);
    while (contentService.firstChild) {
      contentService.removeChild(contentService.firstChild);
    }
    _servicePanels = {};
    _activePanelName = null;
  }

  /**
   * Update navbar connection badge based on connection count.
   */
  function updateConnectionBadge() {
    var dot = document.getElementById('connectionDot');
    var label = document.getElementById('connectionLabel');
    var count = getConnectionCount();

    if (count === 0) {
      dot.classList.remove('connected');
      label.textContent = 'Disconnected';
      connectedStatus = false;
    } else if (count === 1) {
      dot.classList.add('connected');
      label.textContent = 'Connected';
      connectedStatus = true;
    } else {
      dot.classList.add('connected');
      label.textContent = count + ' brokers';
      connectedStatus = true;
    }

    renderBrokerChips();
  }

  /**
   * Render broker chips in the navbar showing each connected broker.
   */
  function renderBrokerChips() {
    var container = document.getElementById('connectedBrokers');
    container.innerHTML = '';

    Object.keys(MM.connections).forEach(function (brokerUrl) {
      var chip = document.createElement('span');
      chip.classList.add('broker-chip');

      var chipLabel = document.createElement('span');
      chipLabel.textContent = brokerUrl;

      var closeBtn = document.createElement('button');
      closeBtn.classList.add('broker-chip-close');
      closeBtn.title = 'Disconnect ' + brokerUrl;
      closeBtn.innerHTML = '<i class="bi bi-x"></i>';
      closeBtn.onclick = function (e) {
        e.stopPropagation();
        confirmDisconnectBroker(brokerUrl);
      };

      chip.appendChild(chipLabel);
      chip.appendChild(closeBtn);
      container.appendChild(chip);
    });
  }

  /**
   * Show a confirm dialog before disconnecting a broker.
   *
   * @param {string} brokerUrl - The broker address to disconnect.
   */
  function confirmDisconnectBroker(brokerUrl) {
    MM.showConfirm('Disconnect from broker ' + brokerUrl + '?', function () {
      disconnectBroker(brokerUrl);
    });
  }

  /**
   * Change the Connect button state when connection status changes.
   * Kept for backward compatibility — wraps updateConnectionBadge().
   *
   * @param {string} status - The connection status.
   */
  function changeConnectButtonState(status) {
    if (status === CONNECTION_STATUS.CONNECTED || status === CONNECTION_STATUS.DISCONNECTED) {
      updateConnectionBadge();
    }
  }

  /**
   * Activates the GUI list item element and loads the content for the service.
   *
   * @param {HTMLElement} element - The HTML element representing the service.
   * @param {string} serviceName - The name of the service to load.
   */
  function activateItemAndLoadContent(element, serviceName) {
    activateItem(element);

    // Set active broker context from clicked element
    var brokerUrl = element.getAttribute('data-broker-url');
    if (brokerUrl && MM.connections[brokerUrl]) {
      MM.activeBrokerUrl = brokerUrl;
      MM.brokerUrl = brokerUrl;
      MM.routingKey = MM.connections[brokerUrl].routingKey;
      MM.serviceClient.setBrokerUrl(brokerUrl);
    }

    var serviceInfo = MM.servicesInfor[serviceName];
    if (serviceInfo.gui_support === true) {
      var callBackFunc = function () {
        loadServiceContent(serviceName, DIV_NAME.SERVICE_CONTENT_DIV);
      };
      checkAndGetTheServiceGUIResources(serviceName, callBackFunc);
    } else {
      showServiceAPIExplorer(serviceName);
    }
  }

  /**
   * Loads GUI resources of a service into a dynamic div.
   *
   * @param {string} serviceName - The name of the service for loading GUI content.
   * @param {string} dynamicContentName - The name of the div where content will be loaded.
   * @param {string} callbackName - Optional callback function name after loading.
   */
  function loadServiceContent(serviceName, dynamicContentName, callbackName) {
    callbackName = callbackName || '';
    var contentDiv = document.getElementById(dynamicContentName);

    // --- Cache hit: show existing panel without re-running loadFunction ---
    if (_servicePanels[serviceName]) {
      _deactivateCurrentPanel();
      var panel = _servicePanels[serviceName];
      var shellType = panel.getAttribute('data-shell-type');
      // Restore visibility — undo the absolute-positioning hide
      panel.style.display = '';
      panel.style.visibility = '';
      panel.style.position = '';
      panel.style.pointerEvents = '';
      panel.style.left = '';
      panel.style.top = '';
      panel.style.width = '';
      _activePanelName = serviceName;
      // Restore unloadFunction reference
      var unloadName = 'unload' + serviceName;
      unloadFunction = window[unloadName] || null;

      // Re-register the correct shell's response callbacks so the active
      // shell receives service responses (not the previously active shell).
      if (shellType === 'qml' && window.QtShellManager) {
        window.QtShellManager.activateBridge();
      } else if (shellType === 'widget' && window.WidgetShellManager) {
        window.WidgetShellManager.activateBridge();
      }

      if (callbackName !== '' && typeof window[callbackName] === 'function') {
        window[callbackName]();
      }
      return;
    }

    // --- Cache miss: multi-tier GUI detection ---
    var folderPath = SERVICES_GUI_FOLDER + '/' + serviceName + MM.servicesInfor[serviceName].version;

    _loadServiceGUIMultiTier(serviceName, folderPath, contentDiv, callbackName);
  }

  /**
   * Multi-tier GUI loading: schema → QML/Widget Shell → Qt WASM → HTML → API Explorer.
   *
   * Tier 1a: gui_schema.json "renderer":"qt"      → QtShellManager (QML Shell)
   * Tier 1b: gui_schema.json "renderer":"widget"   → WidgetShellManager (Widget Shell)
   * Tier 1c: gui_schema.json (no renderer)         → SchemaRenderer (Bootstrap)
   * Tier 1d: *.qml file in service folder           → QtShellManager (QML Shell)
   * Tier 1e: *.ui file in service folder            → WidgetShellManager (Widget Shell)
   * Tier 2:  .wasm file                             → QtWasmLoader (per-service WASM)
   * Tier 3:  .html file                             → Custom HTML
   * Tier 4:  Fallback                               → API Explorer
   */
  function _loadServiceGUIMultiTier(serviceName, folderPath, contentDiv, callbackName) {
    var schemaUrl = folderPath + '/gui_schema.json';
    var htmlUrl = folderPath + '/' + serviceName + '.html';

    // Tier 1: Try gui_schema.json
    fetch(schemaUrl)
      .then(function (resp) {
        if (!resp.ok) throw new Error('no schema');
        return resp.json();
      })
      .then(function (schema) {
        // Tier 1a: Schema with renderer:"qt" → load via QML Shell
        if (schema.renderer === 'qt' && window.QtShellManager) {
          var qmlFile = schema.qml_file || 'ServiceUI.qml';
          var qmlUrl = folderPath + '/' + qmlFile;
          _loadQmlShellGUI(serviceName, qmlUrl, contentDiv, callbackName);
          return;
        }

        // Tier 1b: Schema with renderer:"widget" → load via Widget Shell
        if (schema.renderer === 'widget' && window.WidgetShellManager) {
          var uiFile = schema.ui_file || 'ServiceUI.ui';
          var uiUrl = folderPath + '/' + uiFile;
          _loadWidgetShellGUI(serviceName, uiUrl, contentDiv, callbackName);
          return;
        }

        // Tier 1c: Schema without renderer → render via SchemaRenderer (Bootstrap)
        _deactivateCurrentPanel();
        var wrapper = document.createElement('div');
        wrapper.setAttribute('data-cached-service', serviceName);
        contentDiv.appendChild(wrapper);
        _servicePanels[serviceName] = wrapper;
        _activePanelName = serviceName;
        window.SchemaRenderer.render(schema, wrapper, serviceName);
        // Set unload to cleanup live timers
        window['unload' + serviceName] = function () {
          window.SchemaRenderer.cleanup();
        };
        unloadFunction = window['unload' + serviceName];
        if (callbackName && typeof window[callbackName] === 'function') {
          window[callbackName]();
        }
      })
      .catch(function () {
        // Tier 1d: Check for .qml files → QML Shell (only if shell runtime is loaded)
        // Tier 1e: Check for .ui files → Widget Shell
        var qmlPromise = window.QtShellManager
          ? window.QtShellManager.detect(folderPath)
          : Promise.resolve({ hasQml: false, qmlFile: null });
        var uiPromise = window.WidgetShellManager
          ? window.WidgetShellManager.detect(folderPath)
          : Promise.resolve({ hasUi: false, uiFile: null });

        Promise.all([qmlPromise, uiPromise]).then(function (results) {
          var qmlResult = results[0];
          var uiResult = results[1];

          if (qmlResult.hasQml) {
            var qmlUrl = folderPath + '/' + qmlResult.qmlFile;
            _loadQmlShellGUI(serviceName, qmlUrl, contentDiv, callbackName,
                             folderPath, htmlUrl);
          } else if (uiResult.hasUi) {
            var uiUrl = folderPath + '/' + uiResult.uiFile;
            _loadWidgetShellGUI(serviceName, uiUrl, contentDiv, callbackName,
                                folderPath, htmlUrl);
          } else {
            _tryQtWasmOrHtml(serviceName, folderPath, htmlUrl, contentDiv, callbackName);
          }
        });
      });
  }

  /**
   * Load a service GUI via the shared QML Shell.
   * Falls through to WASM/HTML tier on failure when folderPath/htmlUrl provided.
   */
  function _loadQmlShellGUI(serviceName, qmlUrl, contentDiv, callbackName,
                             folderPath, htmlUrl) {
    _deactivateCurrentPanel();
    var wrapper = document.createElement('div');
    wrapper.setAttribute('data-cached-service', serviceName);
    wrapper.style.cssText = 'height:calc(100vh - 56px - 3rem);';
    contentDiv.appendChild(wrapper);
    _servicePanels[serviceName] = wrapper;
    _activePanelName = serviceName;

    wrapper.setAttribute('data-shell-type', 'qml');

    window.QtShellManager.loadQml(qmlUrl, wrapper, serviceName)
      .catch(function (err) {
        console.warn('QtShellManager failed for', serviceName, err);
        // Remove the failed panel and fall through to next tier.
        if (folderPath) {
          wrapper.remove();
          delete _servicePanels[serviceName];
          _activePanelName = null;
          _tryQtWasmOrHtml(serviceName, folderPath, htmlUrl, contentDiv, callbackName);
        }
      });

    // No-op: panel cache hides/shows via display:none.
    window['unload' + serviceName] = function () {};
    unloadFunction = window['unload' + serviceName];
    if (callbackName && typeof window[callbackName] === 'function') {
      window[callbackName]();
    }
  }

  /**
   * Load a service GUI via the shared Widget Shell.
   * Falls through to WASM/HTML tier on failure when folderPath/htmlUrl provided.
   */
  function _loadWidgetShellGUI(serviceName, uiUrl, contentDiv, callbackName,
                                folderPath, htmlUrl) {
    _deactivateCurrentPanel();
    var wrapper = document.createElement('div');
    wrapper.setAttribute('data-cached-service', serviceName);
    wrapper.style.cssText = 'height:calc(100vh - 56px - 3rem);';
    contentDiv.appendChild(wrapper);
    _servicePanels[serviceName] = wrapper;
    _activePanelName = serviceName;

    wrapper.setAttribute('data-shell-type', 'widget');

    window.WidgetShellManager.loadWidget(uiUrl, wrapper, serviceName)
      .catch(function (err) {
        console.warn('WidgetShellManager failed for', serviceName, err);
        // Remove the failed panel and fall through to next tier.
        if (folderPath) {
          wrapper.remove();
          delete _servicePanels[serviceName];
          _activePanelName = null;
          _tryQtWasmOrHtml(serviceName, folderPath, htmlUrl, contentDiv, callbackName);
        }
      });

    // No-op: panel cache hides/shows via display:none.
    window['unload' + serviceName] = function () {};
    unloadFunction = window['unload' + serviceName];
    if (callbackName && typeof window[callbackName] === 'function') {
      window[callbackName]();
    }
  }

  /**
   * Tier 2/3 fallback: try per-service Qt WASM, then custom HTML.
   */
  function _tryQtWasmOrHtml(serviceName, folderPath, htmlUrl, contentDiv, callbackName) {
    if (window.QtWasmLoader) {
      window.QtWasmLoader.detect(folderPath)
        .then(function (hasWasm) {
          if (hasWasm) {
            _deactivateCurrentPanel();
            var wrapper = document.createElement('div');
            wrapper.setAttribute('data-cached-service', serviceName);
            wrapper.setAttribute('data-shell-type', 'wasm');
            wrapper.style.cssText = 'height:calc(100vh - 56px - 3rem);';
            contentDiv.appendChild(wrapper);
            _servicePanels[serviceName] = wrapper;
            _activePanelName = serviceName;

            window.QtWasmLoader.load(folderPath, wrapper, serviceName)
              .catch(function (err) {
                console.warn('QtWasmLoader failed for', serviceName, err);
                MM.showToast('Qt WASM', 'Failed to load: ' + err.message, 'warning');
              });

            // No-op: panel cache hides/shows via display:none.
            // QtWasmLoader.unload() destroys the WASM instance which
            // cannot be re-created on cache-hit, so only call it on
            // full teardown (e.g., disconnect).
            window['unload' + serviceName] = function () {};
            unloadFunction = window['unload' + serviceName];
            if (callbackName && typeof window[callbackName] === 'function') {
              window[callbackName]();
            }
          } else {
            // Tier 3: Try custom HTML
            _fetchAndRenderServiceGUI(serviceName, htmlUrl, contentDiv, callbackName);
          }
        });
    } else {
      // Tier 3: Try custom HTML (QtWasmLoader not loaded)
      _fetchAndRenderServiceGUI(serviceName, htmlUrl, contentDiv, callbackName);
    }
  }

  /**
   * Fetch a service GUI HTML file and render it in the content panel.
   * Also loads the companion .js script.
   */
  function _fetchAndRenderServiceGUI(serviceName, htmlUrl, contentDiv, callbackName) {
    fetch(htmlUrl)
      .then(function (response) {
        if (!response.ok) {
          throw new Error('HTTP ' + response.status);
        }
        return response.text();
      })
      .then(function (htmlContent) {
        _deactivateCurrentPanel();

        // Create a wrapper div for the cached panel
        var wrapper = document.createElement('div');
        wrapper.setAttribute('data-cached-service', serviceName);
        wrapper.innerHTML = htmlContent;
        contentDiv.appendChild(wrapper);
        _servicePanels[serviceName] = wrapper;
        _activePanelName = serviceName;

        var scriptSrc = htmlUrl.replace('.html', '.js');
        if (!isScriptAlreadyAdded(scriptSrc)) {
          var script = document.createElement('script');
          script.src = scriptSrc;
          script.type = 'text/javascript';
          document.head.appendChild(script);

          script.onload = function () {
            if (callbackName !== '' && typeof window[callbackName] === 'function') {
              window[callbackName]();
            }
            var unloadName = 'unload' + serviceName;
            unloadFunction = window[unloadName] || null;
          };
        } else {
          console.log('Script \'' + scriptSrc + '\' has already been loaded.');
          var loadFunctionName = 'load' + serviceName;
          var loadFunction = window[loadFunctionName];
          if (typeof loadFunction === 'function') {
            loadFunction();
          }
          if (callbackName !== '' && typeof window[callbackName] === 'function') {
            window[callbackName]();
          }
          var unloadName = 'unload' + serviceName;
          unloadFunction = window[unloadName] || null;
        }
      })
      .catch(function (error) {
        // <ServiceName>.html not found — try discovering the actual .html file
        var folderPath = htmlUrl.substring(0, htmlUrl.lastIndexOf('/'));
        MM.listServiceFiles(folderPath)
          .then(function (files) {
            var htmlFile = files.find(function (f) { return f.endsWith('.html'); });
            if (htmlFile) {
              var altUrl = folderPath + '/' + htmlFile;
              console.log('Retrying with discovered file:', altUrl);
              _fetchAndRenderServiceGUI(serviceName, altUrl, contentDiv, callbackName);
            } else {
              console.warn('No .html file found in', folderPath, '- showing API explorer');
              showServiceAPIExplorer(serviceName);
            }
          })
          .catch(function () {
            console.warn('Cannot discover GUI files for', serviceName, '- showing API explorer');
            showServiceAPIExplorer(serviceName);
          });
      });
  }

  function normalizePath(p) {
    p = p.replace(/\\/g, '/');
    if (!p.startsWith('/') && !p.match(/^\w+:/)) {
      var baseURL = new URL(window.location.href);
      p = new URL(p, baseURL).href;
    }
    if (p.match(/^\w:/)) {
      p = 'file:///' + p;
    }
    return p;
  }

  function isScriptAlreadyAdded(scriptPath) {
    var absoluteScriptPath = normalizePath(scriptPath);
    return Array.from(document.head.querySelectorAll('script'))
      .some(function (script) { return normalizePath(script.src) === absoluteScriptPath; });
  }

  /**
   * Loads external content from an HTML file into a specified div.
   *
   * @param {string} externalContentFile - Path to the external HTML file.
   * @param {string} dynamicContentName - The name of the div for external content.
   * @param {string} callbackName - Optional callback function name after loading.
   */
  function loadContent(externalContentFile, dynamicContentName, callbackName) {
    callbackName = callbackName || '';
    console.log('Loading service content...');
    var dynamicContentDiv = document.getElementById(dynamicContentName);

    if (externalContentFile) {
      fetch(externalContentFile)
        .then(function (response) { return response.text(); })
        .then(function (htmlContent) {
          if (dynamicContentName === 'serviceContent' && typeof unloadFunction === 'function') {
            unloadFunction();
          }
          dynamicContentDiv.innerHTML = htmlContent;

          var scriptSrc = externalContentFile.replace('.html', '.js');
          if (!isScriptAlreadyAdded(scriptSrc)) {
            var script = document.createElement('script');
            script.src = scriptSrc;
            script.type = 'text/javascript';
            document.head.appendChild(script);

            script.onload = function () {
              if (callbackName !== '' && typeof window[callbackName] === 'function') {
                window[callbackName]();
              }
              if (dynamicContentName === 'serviceContent') {
                var filename = externalContentFile.split(/[\\/]/).pop().replace(/\..+$/, '');
                var functionName = 'unload' + filename;
                unloadFunction = window[functionName];
              }
            };
          } else {
            console.log('Script \'' + scriptSrc + '\' has already been loaded.');
            var filename = externalContentFile.split(/[\\/]/).pop().replace(/\..+$/, '');
            var loadFunctionName = 'load' + filename;
            var loadFunction = window[loadFunctionName];
            if (typeof loadFunction === 'function') {
              loadFunction();
            }
            if (callbackName !== '' && typeof window[callbackName] === 'function') {
              window[callbackName]();
            }
            if (dynamicContentName === 'serviceContent') {
              var unloadFunctionName = 'unload' + filename;
              unloadFunction = window[unloadFunctionName];
            }
          }
        })
        .catch(function (error) {
          console.error('Error loading external content:', error);
        });
    }
  }

  /************************************************************
   *              Broker Section DOM Management                *
   ************************************************************/

  /**
   * Create or retrieve the broker section wrapper for a given broker URL.
   *
   * @param {string} brokerUrl - The broker address (host:port).
   * @returns {HTMLElement} The broker section element.
   */
  function createBrokerSection(brokerUrl) {
    var servicesList = document.getElementById(DIV_NAME.SERVICE_LIST_DIV);
    var brokerId = sanitizeBrokerId(brokerUrl);
    var existing = servicesList.querySelector('.broker-section[data-broker-url="' + brokerUrl + '"]');
    if (existing) return existing;

    var section = document.createElement('div');
    section.classList.add('broker-section');
    section.setAttribute('data-broker-url', brokerUrl);

    // Header (hidden in single-broker mode via CSS)
    var header = document.createElement('div');
    header.classList.add('broker-header');

    var labelSpan = document.createElement('span');
    labelSpan.classList.add('broker-label');
    labelSpan.textContent = brokerUrl;

    var badge = document.createElement('span');
    badge.classList.add('broker-badge');
    badge.textContent = '0';

    var disconnectBtn = document.createElement('button');
    disconnectBtn.classList.add('broker-disconnect-btn');
    disconnectBtn.title = 'Disconnect this broker';
    disconnectBtn.innerHTML = '<i class="bi bi-x-lg"></i>';
    disconnectBtn.onclick = function (e) {
      e.stopPropagation();
      confirmDisconnectBroker(brokerUrl);
    };

    header.appendChild(labelSpan);
    header.appendChild(badge);
    header.appendChild(disconnectBtn);

    var accordion = document.createElement('div');
    accordion.classList.add('broker-accordion');

    section.appendChild(header);
    section.appendChild(accordion);
    servicesList.appendChild(section);

    return section;
  }

  /**
   * Update the service count badge on a broker header.
   *
   * @param {string} brokerUrl - The broker address.
   */
  function updateBrokerBadge(brokerUrl) {
    var servicesList = document.getElementById(DIV_NAME.SERVICE_LIST_DIV);
    var section = servicesList.querySelector('.broker-section[data-broker-url="' + brokerUrl + '"]');
    if (!section) return;
    var items = section.querySelectorAll('.list-group-item[data-service-name]');
    var badge = section.querySelector('.broker-badge');
    if (badge) badge.textContent = items.length;
  }

  /**
   * Toggle multi-broker class for progressive disclosure.
   * When only one broker is connected, broker headers are hidden.
   */
  function updateBrokerHeaders() {
    var servicesList = document.getElementById(DIV_NAME.SERVICE_LIST_DIV);
    if (getConnectionCount() > 1) {
      servicesList.classList.add('multi-broker');
    } else {
      servicesList.classList.remove('multi-broker');
    }
  }

  /**
   * Create a single service list-item button for the sidebar.
   *
   * @param {object} item - { label, iconSrc, serviceName, downloadable }
   * @param {string} [brokerUrl] - The broker URL to tag on the element.
   * @returns {HTMLElement}
   */
  function _createServiceListItem(item, brokerUrl) {
    var listItem = document.createElement('button');
    listItem.type = 'button';
    listItem.classList.add('list-group-item', 'list-group-item-action');
    listItem.setAttribute('aria-current', 'true');
    listItem.setAttribute('data-service-name', item.serviceName);
    if (brokerUrl) {
      listItem.setAttribute('data-broker-url', brokerUrl);
    }

    listItem.onclick = function () {
      if (listItem.classList.contains('service-disabled')) {
        return;
      }
      activateItemAndLoadContent(listItem, item.serviceName);
    };

    var icon = document.createElement('img');
    icon.src = item.iconSrc;
    icon.alt = 'Icon';
    icon.classList.add('icon');

    var label = document.createTextNode(item.label);

    var helperBtn = document.createElement('span');
    helperBtn.classList.add('helper-btn');
    helperBtn.innerHTML = '<i class="bi bi-code-slash"></i>';
    helperBtn.title = 'Code Example';
    helperBtn.onclick = function (e) {
      e.stopPropagation();
      showServiceHelper(item.serviceName);
    };

    listItem.appendChild(icon);
    listItem.appendChild(label);
    listItem.appendChild(helperBtn);

    if (item.downloadable) {
      var downloadBtn = document.createElement('span');
      downloadBtn.classList.add('helper-btn', 'download-btn');
      downloadBtn.innerHTML = '<i class="bi bi-download"></i>';
      downloadBtn.title = 'Download Service';
      downloadBtn.onclick = function (e) {
        e.stopPropagation();
        downloadServiceFiles(item.serviceName);
      };
      listItem.appendChild(downloadBtn);
    }

    return listItem;
  }

  /**
   * Dynamically generates accordion items for services in the sidebar.
   * Supports multi-broker by appending to the correct broker section.
   *
   * @param {Array} data - Structured information for multiple services.
   * @param {string} [brokerUrl] - The broker URL to scope items to.
   */
  function createAccordionItems(data, brokerUrl) {
    var targetElement;

    if (brokerUrl) {
      var section = createBrokerSection(brokerUrl);
      targetElement = section.querySelector('.broker-accordion');
    } else {
      targetElement = document.getElementById(DIV_NAME.SERVICE_LIST_DIV);
    }

    var prefix = brokerUrl ? sanitizeBrokerId(brokerUrl) + '_' : '';

    data.forEach(function (section) {
      var contentId = prefix + section.contentId;

      var accordionItem = document.createElement('div');
      accordionItem.classList.add('accordion-item');

      var accordionHeader = document.createElement('h2');
      accordionHeader.classList.add('accordion-header');

      var accordionButton = document.createElement('button');
      accordionButton.classList.add('accordion-button');
      accordionButton.type = 'button';
      accordionButton.dataset.bsToggle = 'collapse';
      accordionButton.dataset.bsTarget = '#' + contentId;
      accordionButton.setAttribute('aria-expanded', 'true');
      accordionButton.textContent = section.title;

      accordionHeader.appendChild(accordionButton);

      var accordionCollapse = document.createElement('div');
      accordionCollapse.id = contentId;
      accordionCollapse.classList.add('accordion-collapse', 'collapse', 'show');

      var accordionBody = document.createElement('div');
      accordionBody.classList.add('accordion-body');

      var listGroup = document.createElement('div');
      listGroup.classList.add('list-group');

      section.items.forEach(function (item) {
        listGroup.appendChild(_createServiceListItem(item, brokerUrl));
      });

      accordionBody.appendChild(listGroup);
      accordionCollapse.appendChild(accordionBody);

      accordionItem.appendChild(accordionHeader);
      accordionItem.appendChild(accordionCollapse);

      targetElement.appendChild(accordionItem);
    });

    if (brokerUrl) {
      updateBrokerBadge(brokerUrl);
    }
  }

  /************************************************************
   *             Service API Explorer (non-GUI services)      *
   ************************************************************/

  /**
   * Renders a generic API explorer for services without custom GUI.
   *
   * @param {string} serviceName - The service name key in MM.servicesInfor.
   */
  function showServiceAPIExplorer(serviceName) {
    var serviceInfo = MM.servicesInfor[serviceName];
    var contentDiv = document.getElementById(DIV_NAME.SERVICE_CONTENT_DIV);

    _deactivateCurrentPanel();

    var methods = serviceInfo.methods || [];
    var methodsInfo = serviceInfo.methods_info || {};

    // If SchemaAutoGen + SchemaRenderer are available and methods_info has data,
    // generate a schema-driven UI instead of the raw API explorer.
    if (window.SchemaAutoGen && window.SchemaRenderer &&
        methods.length > 0 && Object.keys(methodsInfo).length > 0) {
      var schema = window.SchemaAutoGen.fromMethodsInfo(serviceName, serviceInfo);
      var wrapper = document.createElement('div');
      wrapper.setAttribute('data-cached-service', serviceName);
      contentDiv.appendChild(wrapper);
      _servicePanels[serviceName] = wrapper;
      _activePanelName = serviceName;
      window.SchemaRenderer.render(schema, wrapper, serviceName);
      window['unload' + serviceName] = function () {
        window.SchemaRenderer.cleanup();
      };
      unloadFunction = window['unload' + serviceName];
      return;
    }

    // Fallback: manual API Explorer for services with no metadata

    // Build method options
    var methodOptions = '<option value="" disabled selected>-- Select a method --</option>';
    methods.forEach(function (m) {
      methodOptions += '<option value="' + _escapeHtml(m) + '">' + _escapeHtml(m) + '</option>';
    });

    var wrapper = document.createElement('div');
    wrapper.innerHTML =
      '<div class="card api-explorer-card">' +
        '<div class="card-header d-flex align-items-center justify-content-between">' +
          '<div>' +
            '<h5 class="mb-0">' + _escapeHtml(serviceInfo.name || serviceName) + ' ' +
              '<span class="badge bg-secondary">' + _escapeHtml(serviceInfo.version || '') + '</span>' +
            '</h5>' +
            '<small class="text-muted">' + _escapeHtml(serviceInfo.description || serviceInfo.shortdesc || '') + '</small>' +
          '</div>' +
        '</div>' +
        '<div class="card-body">' +

          // Method selector
          '<div class="mb-3">' +
            '<label for="apiMethodSelect" class="form-label fw-semibold">Method</label>' +
            '<select class="form-select" id="apiMethodSelect">' +
              methodOptions +
            '</select>' +
          '</div>' +

          // Arguments area (populated dynamically)
          '<div id="apiArgsContainer" class="mb-3" style="display:none;">' +
            '<label class="form-label fw-semibold">Arguments</label>' +
            '<div id="apiArgsFields"></div>' +
          '</div>' +

          // Execute button
          '<button class="btn btn-primary" id="apiExecuteBtn" disabled>' +
            '<i class="bi bi-play-fill me-1"></i>Execute' +
          '</button>' +

          // Response area
          '<div id="apiResponseContainer" class="mt-4" style="display:none;">' +
            '<label class="form-label fw-semibold">Response</label>' +
            '<div class="d-flex align-items-center mb-2">' +
              '<span class="badge me-2" id="apiResultBadge">-</span>' +
              '<small class="text-muted" id="apiResponseTime"></small>' +
            '</div>' +
            '<pre class="api-response-pre" id="apiResponseData"></pre>' +
          '</div>' +

        '</div>' +
      '</div>';

    contentDiv.appendChild(wrapper);

    // Wire events
    var methodSelect = document.getElementById('apiMethodSelect');
    var executeBtn = document.getElementById('apiExecuteBtn');

    methodSelect.addEventListener('change', function () {
      _renderArgsFields(serviceName, methodSelect.value);
      executeBtn.disabled = false;
    });

    executeBtn.addEventListener('click', function () {
      _executeAPIMethod(serviceName, methodSelect.value);
    });
  }

  /**
   * Render argument input fields for a selected method.
   */
  function _renderArgsFields(serviceName, methodName) {
    var serviceInfo = MM.servicesInfor[serviceName];
    var methodsInfo = serviceInfo.methods_info || {};
    var argsContainer = document.getElementById('apiArgsContainer');
    var argsFields = document.getElementById('apiArgsFields');

    argsFields.innerHTML = '';

    var methodDetail = methodsInfo[methodName];
    if (methodDetail && methodDetail.arguments && methodDetail.arguments.length > 0) {
      argsContainer.style.display = '';
      methodDetail.arguments.forEach(function (arg, idx) {
        var fieldId = 'apiArg_' + idx;
        var conditionBadge = '';
        if (arg.condition) {
          conditionBadge = '<span class="badge bg-' +
            (arg.condition === 'required' ? 'danger' : 'secondary') +
            ' ms-1">' + _escapeHtml(arg.condition) + '</span>';
        }
        var typeBadge = '';
        if (arg.type) {
          typeBadge = '<span class="badge bg-info text-dark ms-1">' + _escapeHtml(arg.type) + '</span>';
        }

        var fieldHtml =
          '<div class="api-arg-field mb-2">' +
            '<label for="' + fieldId + '" class="form-label mb-1">' +
              '<code>' + _escapeHtml(arg.name || 'arg' + idx) + '</code>' +
              conditionBadge + typeBadge +
            '</label>' +
            '<input type="text" class="form-control form-control-sm api-arg-input" ' +
              'id="' + fieldId + '" ' +
              'data-arg-index="' + idx + '" ' +
              'placeholder="' + _escapeHtml(arg.description || '') + '"' +
              (arg.default != null ? ' value="' + _escapeHtml(String(arg.default)) + '"' : '') +
            '>' +
          '</div>';

        argsFields.innerHTML += fieldHtml;
      });
    } else {
      // No known argument info — show a single JSON textarea
      argsContainer.style.display = '';
      argsFields.innerHTML =
        '<textarea class="form-control form-control-sm font-monospace" id="apiArgsRaw" rows="3" ' +
          'placeholder="Arguments as JSON array, e.g. [&quot;value1&quot;, 123] or leave empty for null"></textarea>';
    }
  }

  /**
   * Execute the selected API method and display the response.
   */
  function _executeAPIMethod(serviceName, methodName) {
    var serviceInfo = MM.servicesInfor[serviceName];
    var methodsInfo = serviceInfo.methods_info || {};
    var methodDetail = methodsInfo[methodName];

    // Collect arguments
    var args = null;
    var rawTextarea = document.getElementById('apiArgsRaw');
    if (rawTextarea) {
      // Free-form JSON input
      var rawVal = rawTextarea.value.trim();
      if (rawVal !== '') {
        try {
          args = JSON.parse(rawVal);
        } catch (e) {
          showToast('Invalid Arguments', 'Could not parse JSON: ' + e.message, 'danger');
          return;
        }
      }
    } else if (methodDetail && methodDetail.arguments && methodDetail.arguments.length > 0) {
      // Structured input fields
      var argValues = [];
      var argInputs = document.querySelectorAll('.api-arg-input');
      argInputs.forEach(function (input) {
        var val = input.value.trim();
        if (val === '') {
          argValues.push(null);
        } else {
          // Try to parse as JSON (number, bool, object), fall back to string
          try {
            argValues.push(JSON.parse(val));
          } catch (e) {
            argValues.push(val);
          }
        }
      });
      // Only send args if there are non-null values
      var hasValues = argValues.some(function (v) { return v !== null; });
      if (hasValues) {
        args = argValues;
      }
    }

    var requestData = {
      method: methodName,
      args: args
    };

    // Determine routing: use service's routing_key via exchange, or direct queue
    var executeBtn = document.getElementById('apiExecuteBtn');
    executeBtn.disabled = true;
    executeBtn.innerHTML = '<span class="spinner-border spinner-border-sm me-1"></span>Executing...';

    var responseContainer = document.getElementById('apiResponseContainer');
    responseContainer.style.display = 'none';

    var startTime = Date.now();

    var requestPromise;
    if (serviceInfo.routing_key) {
      requestPromise = requestService(requestData, SERVICES_EXCHANGE_NAME, serviceInfo.routing_key);
    } else {
      requestPromise = MM.requestServiceDirect(requestData, serviceName);
    }

    requestPromise
      .then(function (data) {
        var elapsed = Date.now() - startTime;
        _showAPIResponse(data, elapsed);
      })
      .catch(function (error) {
        var elapsed = Date.now() - startTime;
        _showAPIResponse({
          request: methodName,
          result: 'exception',
          result_data: error.message || String(error)
        }, elapsed);
      })
      .finally(function () {
        executeBtn.disabled = false;
        executeBtn.innerHTML = '<i class="bi bi-play-fill me-1"></i>Execute';
      });
  }

  /**
   * Display the API response in the response area.
   */
  function _showAPIResponse(data, elapsedMs) {
    var responseContainer = document.getElementById('apiResponseContainer');
    var badge = document.getElementById('apiResultBadge');
    var timeEl = document.getElementById('apiResponseTime');
    var dataEl = document.getElementById('apiResponseData');

    responseContainer.style.display = '';

    var result = data.result || 'unknown';
    var badgeClass = 'bg-success';
    if (result === 'fail') badgeClass = 'bg-warning text-dark';
    if (result === 'exception') badgeClass = 'bg-danger';

    badge.className = 'badge me-2 ' + badgeClass;
    badge.textContent = result;
    timeEl.textContent = elapsedMs + ' ms';

    var resultData = data.result_data;
    // Try to pretty-print if it's JSON string
    if (typeof resultData === 'string') {
      try {
        resultData = JSON.parse(resultData);
      } catch (e) {
        // not JSON, keep as string
      }
    }

    if (typeof resultData === 'object') {
      dataEl.textContent = JSON.stringify(resultData, null, 2);
    } else {
      dataEl.textContent = String(resultData);
    }
  }

  /************************************************************
   *             Service Helper Modal (multi-language)         *
   ************************************************************/

  var helperModal = null;

  /**
   * Generate Python example code for a service using MicroserviceBase transport.
   */
  function _generatePythonCode(serviceName, serviceInfo, brokerHost, brokerPort) {
    var methods = serviceInfo.methods || [];
    var methodsInfo = serviceInfo.methods_info || {};
    var routingKey = serviceInfo.routing_key || serviceName;

    var code = '';
    code += 'from MicroserviceBase import ServiceBase\n';
    code += 'from MicroserviceBase.factory import create_transport\n';
    code += '\n';
    code += '# Create transport (connects to RabbitMQ broker)\n';
    code += 'transport = create_transport(\n';
    code += '    \'rabbitmq\',\n';
    code += '    cmd_args=[\'--host\', \'' + brokerHost + '\', \'--port\', \'' + brokerPort + '\'],\n';
    code += '    service_name=\'MyClient\'\n';
    code += ')\n';
    code += '\n';
    code += 'EXCHANGE = \'' + SERVICES_EXCHANGE_NAME + '\'\n';
    code += 'ROUTING_KEY = \'' + routingKey + '\'\n';
    code += '\n';
    code += 'try:\n';

    if (methods.length > 0) {
      methods.forEach(function (methodName, idx) {
        var methodDetail = methodsInfo[methodName];
        var argsValue = 'None';
        var argsComment = '';

        if (methodDetail && methodDetail.arguments && methodDetail.arguments.length > 0) {
          var argNames = methodDetail.arguments.map(function (a) {
            return a.name || 'arg';
          });
          argsComment = '  # args: ' + argNames.join(', ');
          var argPlaceholders = methodDetail.arguments.map(function (a) {
            var desc = a.description || a.name || 'value';
            if (a.type === 'int' || a.type === 'number') return '0';
            if (a.type === 'bool' || a.type === 'boolean') return 'True';
            return '\'' + desc.replace(/\\/g, '\\\\').replace(/'/g, "\\'") + '\'';
          });
          argsValue = '[' + argPlaceholders.join(', ') + ']';
        }

        if (idx > 0) code += '\n';
        code += '    # ' + methodName + '\n';
        code += '    request = ServiceBase.create_request_data(\'' + methodName + '\', ' + argsValue + ')' + argsComment + '\n';
        code += '    response = transport.rpc_call(request, EXCHANGE, ROUTING_KEY)\n';
        code += '    print(f"[' + methodName + '] {response[\'result\']}: {response[\'result_data\']}")\n';
      });
    } else {
      code += '    # No methods available for this service.\n';
      code += '    pass\n';
    }

    code += '\nfinally:\n';
    code += '    transport.disconnect()\n';
    return code;
  }

  /**
   * Generate Robot Framework example code for a service using QConnectBase.
   */
  function _generateRobotCode(serviceName, serviceInfo, brokerHost, brokerPort) {
    var methods = serviceInfo.methods || [];
    var methodsInfo = serviceInfo.methods_info || {};
    var routingKey = serviceInfo.routing_key || serviceName;

    var code = '';
    code += '*** Settings ***\n';
    code += 'Library    QConnectBase.ConnectionManager\n';
    code += 'Library    Collections\n';
    code += '\n';
    code += '*** Variables ***\n';
    code += '${BROKER_HOST}        ' + brokerHost + '\n';
    code += '${BROKER_PORT}        ' + brokerPort + '\n';
    code += '${ROUTING_KEY}        ' + routingKey + '\n';
    code += '${CONNECTION_NAME}    ' + serviceName + '_conn\n';
    code += '\n';
    code += '*** Test Cases ***\n';

    if (methods.length > 0) {
      methods.forEach(function (methodName) {
        var methodDetail = methodsInfo[methodName];
        var argsValue = 'null';

        if (methodDetail && methodDetail.arguments && methodDetail.arguments.length > 0) {
          var argPlaceholders = methodDetail.arguments.map(function (a) {
            if (a.type === 'int' || a.type === 'number') return '0';
            if (a.type === 'bool' || a.type === 'boolean') return 'true';
            var desc = a.description || a.name || 'value';
            return '"' + desc.replace(/\\/g, '\\\\').replace(/"/g, '\\"') + '"';
          });
          argsValue = '[' + argPlaceholders.join(', ') + ']';
        }

        code += 'Test ' + methodName + '\n';
        code += '    [Documentation]    Call ' + methodName;
        if (methodDetail && methodDetail.description) {
          code += ' - ' + methodDetail.description;
        }
        code += '\n';
        code += '    ${config}=    Evaluate    json.loads(\'{"address":"${BROKER_HOST}","port":"${BROKER_PORT}","routing_key":"${ROUTING_KEY}"}\')    json\n';
        code += '    Connect    conn_name=${CONNECTION_NAME}\n    ...        conn_type=RabbitmqClient\n    ...        conn_conf=${config}\n';
        code += '    ${res}=    Verify    conn_name=${CONNECTION_NAME}\n';
        code += '    ...    send_cmd={ "method": "' + methodName + '", "args": ' + argsValue + ' }\n';
        code += '    ...    search_pattern=(.*)\n';
        code += '    ...    timeout=30\n';
        code += '    Log To Console    ${res}\n';
        code += '    [Teardown]    Disconnect    ${CONNECTION_NAME}\n';
        code += '\n';
      });
    } else {
      code += 'Test No Methods\n';
      code += '    [Documentation]    No methods available for this service.\n';
      code += '    Log    No methods to call.\n';
    }

    return code;
  }

  /**
   * Generate JavaScript example code for a service using the ServiceClient / fetch API.
   */
  function _generateJavaScriptCode(serviceName, serviceInfo, brokerHost, brokerPort) {
    var methods = serviceInfo.methods || [];
    var methodsInfo = serviceInfo.methods_info || {};
    var routingKey = serviceInfo.routing_key || serviceName;
    var apiUrl = MM.serviceClient ? MM.serviceClient.apiUrl : 'http://localhost:8000';

    var code = '';
    code += '// Using the FastAPI bridge REST endpoint\n';
    code += 'const API_URL   = \'' + apiUrl + '/api/request\';\n';
    code += 'const EXCHANGE  = \'' + SERVICES_EXCHANGE_NAME + '\';\n';
    code += 'const ROUTING_KEY = \'' + routingKey + '\';\n';
    code += '\n';
    code += '/**\n';
    code += ' * Send an RPC request to a service method.\n';
    code += ' * @param {string} method - Service method name.\n';
    code += ' * @param {Array|null} args - Method arguments.\n';
    code += ' * @returns {Promise<object>} Service response.\n';
    code += ' */\n';
    code += 'async function callService(method, args = null) {\n';
    code += '  const res = await fetch(API_URL, {\n';
    code += '    method: \'POST\',\n';
    code += '    headers: { \'Content-Type\': \'application/json\' },\n';
    code += '    body: JSON.stringify({\n';
    code += '      method,\n';
    code += '      args,\n';
    code += '      exchange: EXCHANGE,\n';
    code += '      routing_key: ROUTING_KEY,\n';
    code += '    }),\n';
    code += '  });\n';
    code += '  if (!res.ok) throw new Error(`Request failed: ${res.status}`);\n';
    code += '  return res.json();\n';
    code += '}\n';
    code += '\n';
    code += '// --- Example calls ---\n';

    if (methods.length > 0) {
      code += '(async () => {\n';
      methods.forEach(function (methodName) {
        var methodDetail = methodsInfo[methodName];
        var argsValue = 'null';
        var argsComment = '';

        if (methodDetail && methodDetail.arguments && methodDetail.arguments.length > 0) {
          var argNames = methodDetail.arguments.map(function (a) {
            return a.name || 'arg';
          });
          argsComment = '  // args: ' + argNames.join(', ');
          var argPlaceholders = methodDetail.arguments.map(function (a) {
            var desc = a.description || a.name || 'value';
            if (a.type === 'int' || a.type === 'number') return '0';
            if (a.type === 'bool' || a.type === 'boolean') return 'true';
            return '\'' + desc.replace(/\\/g, '\\\\').replace(/'/g, "\\'") + '\'';
          });
          argsValue = '[' + argPlaceholders.join(', ') + ']';
        }

        code += '\n';
        code += '  // ' + methodName + '\n';
        code += '  const r_' + methodName.replace(/\W/g, '_') + ' = await callService(\'' + methodName + '\', ' + argsValue + ');' + argsComment + '\n';
        code += '  console.log(\'' + methodName + ':\', r_' + methodName.replace(/\W/g, '_') + ');\n';
      });
      code += '})();\n';
    } else {
      code += '// No methods available for this service.\n';
    }

    return code;
  }

  /**
   * Show a modal with example code for calling a service's APIs.
   * Supports multiple languages via tabs (Python, JavaScript).
   *
   * @param {string} serviceName - The service name key in MM.servicesInfor.
   */
  function showServiceHelper(serviceName) {
    var serviceInfo = MM.servicesInfor[serviceName];
    if (!serviceInfo) {
      showToast('Error', 'No information available for ' + serviceName, 'danger');
      return;
    }

    var version = serviceInfo.version || '';
    var description = serviceInfo.description || serviceInfo.shortdesc || '';

    // Resolve broker host/port from the service's owning broker
    var resolvedBroker = resolveBrokerUrlForService(serviceName) || MM.brokerUrl || 'localhost:5672';
    var brokerHost = 'localhost';
    var brokerPort = '5672';
    if (resolvedBroker) {
      var parts = resolvedBroker.split(':');
      brokerHost = parts[0] || 'localhost';
      brokerPort = parts[1] || '5672';
    }

    // Generate code for each language
    var pythonCode = _generatePythonCode(serviceName, serviceInfo, brokerHost, brokerPort);
    var jsCode = _generateJavaScriptCode(serviceName, serviceInfo, brokerHost, brokerPort);
    var robotCode = _generateRobotCode(serviceName, serviceInfo, brokerHost, brokerPort);

    // Build modal body with header + language tabs
    var titleHtml = '<h5>' + _escapeHtml(serviceInfo.name || serviceName) + ' ' +
      '<span class="badge bg-secondary">' + _escapeHtml(version) + '</span></h5>';
    if (description) {
      titleHtml += '<p class="text-muted mb-3">' + _escapeHtml(description) + '</p>';
    }

    var tabsHtml =
      '<ul class="nav nav-tabs helper-lang-tabs" role="tablist">' +
        '<li class="nav-item" role="presentation">' +
          '<button class="nav-link active" data-bs-toggle="tab" data-bs-target="#helperTabPython" ' +
            'type="button" role="tab" aria-selected="true">' +
            '<i class="bi bi-filetype-py me-1"></i>Python</button>' +
        '</li>' +
        '<li class="nav-item" role="presentation">' +
          '<button class="nav-link" data-bs-toggle="tab" data-bs-target="#helperTabJS" ' +
            'type="button" role="tab" aria-selected="false">' +
            '<i class="bi bi-filetype-js me-1"></i>JavaScript</button>' +
        '</li>' +
        '<li class="nav-item" role="presentation">' +
          '<button class="nav-link" data-bs-toggle="tab" data-bs-target="#helperTabRobot" ' +
            'type="button" role="tab" aria-selected="false">' +
            '<i class="bi bi-robot me-1"></i>Robot</button>' +
        '</li>' +
      '</ul>' +
      '<div class="tab-content">' +
        '<div class="tab-pane fade show active" id="helperTabPython" role="tabpanel">' +
          '<pre class="helper-code-pre" id="helperCodePython">' + _escapeHtml(pythonCode) + '</pre>' +
        '</div>' +
        '<div class="tab-pane fade" id="helperTabJS" role="tabpanel">' +
          '<pre class="helper-code-pre" id="helperCodeJS">' + _escapeHtml(jsCode) + '</pre>' +
        '</div>' +
        '<div class="tab-pane fade" id="helperTabRobot" role="tabpanel">' +
          '<pre class="helper-code-pre" id="helperCodeRobot">' + _escapeHtml(robotCode) + '</pre>' +
        '</div>' +
      '</div>';

    document.getElementById('helperModalTitle').textContent = 'Helper \u2014 ' + (serviceInfo.name || serviceName);
    document.getElementById('helperModalBody').innerHTML = titleHtml + tabsHtml;

    if (!helperModal) {
      helperModal = new bootstrap.Modal(document.getElementById('helperModal'));
    }
    helperModal.show();
  }

  /**
   * Get the code text from the currently active helper tab.
   * @returns {string}
   */
  function _getActiveHelperCode() {
    var activePane = document.querySelector('#helperModalBody .tab-pane.active.show');
    if (!activePane) return '';
    var pre = activePane.querySelector('pre');
    return pre ? pre.textContent : '';
  }

  // Copy button handler
  document.getElementById('btnCopyHelper').addEventListener('click', function () {
    var code = _getActiveHelperCode();
    if (!code) return;
    navigator.clipboard.writeText(code).then(function () {
      showToast('Copied', 'Code copied to clipboard.', 'success');
    }).catch(function () {
      // Fallback for older browsers
      var textarea = document.createElement('textarea');
      textarea.value = code;
      textarea.style.position = 'fixed';
      textarea.style.opacity = '0';
      document.body.appendChild(textarea);
      textarea.select();
      document.execCommand('copy');
      document.body.removeChild(textarea);
      showToast('Copied', 'Code copied to clipboard.', 'success');
    });
  });

  /**
   * Escape HTML special characters.
   */
  function _escapeHtml(str) {
    if (!str) return '';
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  /************************************************************
   *             Element Events Handling Section              *
   ************************************************************/

  // Detect transport mode on startup
  if (window.electronAPI) {
    console.log('[app] Running in Electron mode (preload bridge detected)');
  } else {
    console.log('[app] Running in Browser mode (FastAPI transport)');
  }

  document.getElementById('btnConnect').addEventListener('click', function () {
    // New flow: the Connect button opens the Consul connect modal.  The
    // legacy broker login (connect() -> loginModal) is no longer reachable
    // from the UI but still works if called programmatically.
    _openConsulConnectModal();
  });

  var _consulConnectModal = null;

  // Multi-Consul state: each entry is { url, leader, services: [...] }
  // where ``services`` is the raw service list fetched from this Consul.
  var _connectedConsuls = [];   // array kept in insertion order
  var CONSULS_STORAGE_KEY = 'mm_consul_urls';     // JSON array of URLs

  function _saveConsulUrls() {
    try {
      var urls = _connectedConsuls.map(function (c) { return c.url; });
      localStorage.setItem(CONSULS_STORAGE_KEY, JSON.stringify(urls));
    } catch (e) {}
  }

  function _loadSavedConsulUrls() {
    try {
      var raw = localStorage.getItem(CONSULS_STORAGE_KEY);
      if (!raw) return [];
      var arr = JSON.parse(raw);
      return Array.isArray(arr) ? arr : [];
    } catch (e) { return []; }
  }

  function _openConsulConnectModal() {
    var modalEl = document.getElementById('consulConnectModal');
    if (!modalEl) return;
    if (!_consulConnectModal) {
      _consulConnectModal = new bootstrap.Modal(modalEl);
    }

    // Prefill with a reasonable default or the most recent URL typed.
    try {
      var saved = localStorage.getItem('mm_consul_last_input_url');
      document.getElementById('consulConnectUrl').value =
        saved || 'http://127.0.0.1:8500';
    } catch (e) {}

    _setConsulConnectResult('', '');
    _consulConnectModal.show();
  }

  function _setConsulConnectResult(kind, html) {
    var el = document.getElementById('consulConnectResult');
    if (!el) return;
    if (!kind) {
      el.className = 'small';
      el.innerHTML = '';
    } else {
      el.className = 'small alert alert-' + kind + ' py-2 mb-0 mt-2';
      el.innerHTML = html;
    }
  }

  var _btnConsulConnectSubmit = document.getElementById('btnConsulConnectSubmit');
  if (_btnConsulConnectSubmit) {
    _btnConsulConnectSubmit.addEventListener('click', function () {
      _submitConsulConnect();
    });
  }

  var _btnConsulDetect = document.getElementById('btnConsulDetect');
  if (_btnConsulDetect) {
    _btnConsulDetect.addEventListener('click', function () {
      _runConsulDetect();
    });
  }

  function _runConsulDetect() {
    var btn = document.getElementById('btnConsulDetect');
    var results = document.getElementById('consulDetectResults');
    if (!btn || !results) return;

    btn.disabled = true;
    btn.innerHTML = '<span class="spinner-border spinner-border-sm me-1"></span>Scanning...';
    results.innerHTML =
      '<div class="small text-muted mt-2">' +
      '  <span class="spinner-border spinner-border-sm me-1"></span>' +
      '  Looking for running <code>consul</code> processes...' +
      '</div>';

    MM.consulClient.discover()
      .then(function (data) {
        if (data && data.error) {
          results.innerHTML =
            '<div class="alert alert-danger small mt-2 mb-0">' +
            '  <i class="bi bi-exclamation-triangle me-1"></i>' +
              _escapeHtml(data.error) +
            '</div>';
          return;
        }
        var instances = (data && data.instances) || [];
        // Hide instances that are already in _connectedConsuls so the
        // user isn't offered to re-add what they already have.
        var already = {};
        _connectedConsuls.forEach(function (c) { already[c.url] = 1; });
        instances = instances.filter(function (i) { return !already[i.url]; });

        if (instances.length === 0) {
          results.innerHTML =
            '<div class="alert alert-warning small mt-2 mb-0">' +
            '  <i class="bi bi-exclamation-triangle me-1"></i>' +
            '  No new Consul processes found. ' +
            '</div>';
          return;
        }

        var rows = instances.map(function (inst) {
          var roleBadge = inst.server
            ? '<span class="badge bg-primary ms-1">server</span>'
            : '<span class="badge bg-secondary ms-1">client</span>';
          var versionBadge = inst.version
            ? '<span class="badge bg-light text-dark ms-1">v' + _escapeHtml(inst.version) + '</span>'
            : '';
          var dcBadge = inst.datacenter
            ? '<span class="badge bg-light text-dark ms-1">' + _escapeHtml(inst.datacenter) + '</span>'
            : '';
          var pidBadge = inst.pid
            ? '<span class="badge bg-secondary ms-1">pid ' + inst.pid + '</span>'
            : '';

          return '<button type="button" class="list-group-item list-group-item-action consul-detect-row"' +
                 '  data-url="' + _escapeHtml(inst.url) + '">' +
                 '  <div class="d-flex justify-content-between align-items-center">' +
                 '    <div>' +
                 '      <strong>' + _escapeHtml(inst.node_name || inst.host + ':' + inst.port) + '</strong>' +
                          roleBadge + versionBadge + dcBadge + pidBadge +
                 '      <div class="small text-muted">' + _escapeHtml(inst.url) + '</div>' +
                 '    </div>' +
                 '    <i class="bi bi-chevron-right"></i>' +
                 '  </div>' +
                 '</button>';
        }).join('');

        results.innerHTML =
          '<div class="small text-muted mb-1">' +
          '  Found <strong>' + instances.length + '</strong> Consul process(es) — click to select:' +
          '</div>' +
          '<div class="list-group mb-2">' + rows + '</div>';

        // Wire each row: fill the URL input.  Don't auto-submit — let the
        // user review and click Connect themselves (there might be an
        // ACL token they want to fill in first).
        results.querySelectorAll('.consul-detect-row').forEach(function (row) {
          row.addEventListener('click', function () {
            var url = row.getAttribute('data-url');
            var input = document.getElementById('consulConnectUrl');
            if (input) input.value = url;
            results.querySelectorAll('.consul-detect-row.active')
                   .forEach(function (el) { el.classList.remove('active'); });
            row.classList.add('active');
          });
        });
      })
      .catch(function (err) {
        results.innerHTML =
          '<div class="alert alert-danger small mt-2 mb-0">' +
          '  Detect failed: ' + _escapeHtml(err.message || err) +
          '</div>';
      })
      .finally(function () {
        btn.disabled = false;
        btn.innerHTML = '<i class="bi bi-search me-1"></i>Detect';
      });
  }

  // Clear detect results when the modal closes so stale rows don't
  // linger into the next Connect attempt.
  (function () {
    var modalEl = document.getElementById('consulConnectModal');
    if (modalEl) {
      modalEl.addEventListener('hidden.bs.modal', function () {
        var results = document.getElementById('consulDetectResults');
        if (results) results.innerHTML = '';
      });
    }
  })();

  function _submitConsulConnect() {
    var rawUrl = (document.getElementById('consulConnectUrl').value || '').trim();

    if (!rawUrl) {
      _setConsulConnectResult('warning', 'Consul URL is required.');
      return;
    }
    var url = rawUrl.replace(/\/+$/, '');   // trim trailing slashes
    try { localStorage.setItem('mm_consul_last_input_url', url); } catch (e) {}

    // Dedupe
    var existing = _connectedConsuls.find(function (c) { return c.url === url; });
    if (existing) {
      _setConsulConnectResult('warning', 'Already connected to ' + url + '.');
      return;
    }

    var btn = document.getElementById('btnConsulConnectSubmit');
    if (btn) {
      btn.disabled = true;
      btn.innerHTML = '<span class="spinner-border spinner-border-sm me-1"></span>Connecting...';
    }
    _setConsulConnectResult('info', 'Probing Consul...');

    _connectConsulUrl(url)
      .then(function (conn) {
        _connectedConsuls.push(conn);
        _saveConsulUrls();
        _renderConsulChips();
        _renderAllConnectedConsuls();

        _setConsulConnectResult('success',
          'Connected. ' + conn.services.length + ' service(s) registered.');
        showToast('Consul',
          'Connected to ' + url + ' — ' +
          conn.services.length + ' service(s).', 'success');
        setTimeout(function () {
          if (_consulConnectModal) _consulConnectModal.hide();
        }, 800);
      })
      .catch(function (err) {
        _setConsulConnectResult('danger', 'Connect failed: ' + (err.message || err));
        showToast('Consul', 'Connect failed: ' + (err.message || err), 'danger');
      })
      .finally(function () {
        if (btn) {
          btn.disabled = false;
          btn.innerHTML = '<i class="bi bi-plug me-1"></i>Connect';
        }
      });
  }

  /**
   * Probe a Consul URL, fetch its service catalog (with details), and
   * return a Promise resolving to a connection object
   *   { url, leader, services: [ {name, tags, address, port, grpcServices, instances} ] }
   *
   * The services list is pre-filtered to remove infrastructure entries
   * (consul/nomad/nomad-client).
   */
  function _connectConsulUrl(url) {
    var HIDDEN = { 'consul': 1, 'nomad': 1, 'nomad-client': 1 };
    var leader = '';

    return MM.consulClient.testConnection(url)
      .then(function (health) {
        if (!health || !health.ok) {
          throw new Error((health && health.error) || 'Consul not reachable');
        }
        leader = health.leader || '';
        return MM.consulClient.getServices(url);
      })
      .then(function (servicesMap) {
        var names = Object.keys(servicesMap || {}).filter(function (n) {
          return n && !HIDDEN[n];
        }).sort();
        var detailPromises = names.map(function (name) {
          return MM.consulClient.getServiceDetail(name, url)
            .catch(function () { return []; });
        });
        return Promise.all(detailPromises).then(function (details) {
          var services = names.map(function (name, i) {
            var instances = Array.isArray(details[i]) ? details[i] : [];
            var first = instances[0] || {};
            var svc = first.Service || {};
            return {
              name: name,
              tags: (servicesMap[name] || []),
              address: svc.Address || '',
              port: svc.Port || 0,
              grpcServices: (svc.Meta && svc.Meta.grpc_services) || '',
              instances: instances.length,
              status: _computeServiceStatus(instances)
            };
          });
          return { url: url, leader: leader, services: services, alive: true };
        });
      });
  }

  function _removeConsulConnection(url) {
    _connectedConsuls = _connectedConsuls.filter(function (c) {
      return c.url !== url;
    });
    _saveConsulUrls();
    _renderConsulChips();
    _renderAllConnectedConsuls();
    showToast('Consul', 'Disconnected from ' + url, 'info');
  }

  function _renderConsulChips() {
    var container = document.getElementById('consulChips');
    if (!container) return;
    container.innerHTML = '';

    _connectedConsuls.forEach(function (conn) {
      var chip = document.createElement('div');
      var alive = conn.alive !== false;
      chip.className = 'consul-chip' + (alive ? '' : ' consul-chip-down');
      chip.title = conn.url +
        (conn.leader ? '  (leader: ' + conn.leader + ')' : '') +
        (!alive ? '  — unreachable' + (conn.lastError ? ': ' + conn.lastError : '') : '');

      var label = _shortenConsulUrl(conn.url);
      var iconCls = alive
        ? 'bi bi-compass consul-chip-icon'
        : 'bi bi-plug consul-chip-icon consul-chip-icon-down';

      chip.innerHTML =
        '<i class="' + iconCls + '"></i>' +
        '<span class="consul-chip-label">' + _escapeHtml(label) + '</span>' +
        '<button type="button" class="consul-chip-close" aria-label="Disconnect">' +
        '  <i class="bi bi-x"></i>' +
        '</button>';

      chip.querySelector('.consul-chip-close').addEventListener('click', function (e) {
        e.stopPropagation();
        _removeConsulConnection(conn.url);
      });

      container.appendChild(chip);
    });
  }

  function _shortenConsulUrl(url) {
    // Strip http(s):// for compactness; keep host:port.
    return String(url || '').replace(/^https?:\/\//, '');
  }

  /**
   * Given a list of instance entries from /v1/health/service/{name}, return
   * an overall status object usable for the sidebar indicator.  The entry
   * shape is { Node, Service, Checks: [{Status, ...}] }.
   *
   * Status precedence (worst wins): critical > warning > passing > unknown.
   * Returns:
   *    { kind: 'passing' | 'warning' | 'critical' | 'unknown',
   *      label: string,
   *      passing: N, warning: N, critical: N }
   */
  function _computeServiceStatus(instances) {
    if (!Array.isArray(instances) || instances.length === 0) {
      return { kind: 'unknown', label: 'no instances',
               passing: 0, warning: 0, critical: 0 };
    }
    var p = 0, w = 0, c = 0;
    instances.forEach(function (inst) {
      // Reduce the per-instance checks to one status (worst wins).
      var checks = (inst && inst.Checks) || [];
      var worst = 'passing';
      for (var i = 0; i < checks.length; i++) {
        var s = checks[i].Status;
        if (s === 'critical') { worst = 'critical'; break; }
        if (s === 'warning' && worst !== 'critical') worst = 'warning';
      }
      if (worst === 'critical') c++;
      else if (worst === 'warning') w++;
      else p++;
    });

    var total = p + w + c;
    var kind = 'passing';
    var label = 'running';
    if (c > 0 && p === 0 && w === 0) {
      kind = 'critical';
      label = 'critical';
    } else if (c > 0 || w > 0) {
      kind = 'warning';
      label = 'degraded ' + p + '/' + total;
    } else {
      kind = 'passing';
      label = total > 1 ? ('running ' + p + '/' + total) : 'running';
    }
    return { kind: kind, label: label, passing: p, warning: w, critical: c };
  }

  /**
   * Render the sidebar from the current set of _connectedConsuls.  One
   * accordion group per Consul URL, with its services inside.  Called
   * whenever the connection list changes (add, remove, reload).
   */
  function _renderAllConnectedConsuls() {
    var container = document.getElementById('servicesList');
    if (!container) return;

    container.classList.remove('multi-broker');
    container.innerHTML = '';

    // Rebuild MM.servicesInfor for method lookup and search.  Keys are
    // scoped by URL so two services with the same name on different
    // Consuls don't collide.
    MM.servicesInfor = {};
    _connectedConsuls.forEach(function (conn) {
      conn.services.forEach(function (svc) {
        var key = svc.name + '@' + conn.url;
        MM.servicesInfor[key] = {
          name: svc.name,
          routing_key: svc.name,
          version: '1.0.0',
          tag: svc.tags.join(','),
          shortdesc: svc.grpcServices || 'gRPC service',
          description: 'Consul ' + conn.url + ' @ ' +
                        (svc.address || '?') + ':' + (svc.port || '?'),
          methods: [],
          gui_support: false,
          address: svc.address,
          port: svc.port,
          consulUrl: conn.url
        };
      });
    });

    // If the service shown on the right (API explorer / cached panel) was
    // just deregistered (process killed, Nomad job stopped, agent down,
    // or its Consul cluster disconnected), clear it.  Without this the
    // user is left with a stale panel showing methods for a service that
    // no longer exists.  Also drop the cached panel so re-registration
    // picks up fresh metadata instead of resurrecting the stale element.
    if (_activePanelName && !MM.servicesInfor[_activePanelName]) {
      var goneName = _activePanelName;
      _deactivateCurrentPanel();
      if (_servicePanels[goneName]) {
        try { _servicePanels[goneName].remove(); } catch (e) { /* ignore */ }
        delete _servicePanels[goneName];
      }
    }

    if (_connectedConsuls.length === 0) {
      container.innerHTML =
        '<div class="sidebar-empty-hint">' +
        '  Click <strong>Connect</strong> in the toolbar to connect to a ' +
        '  Consul cluster.' +
        '</div>';
      return;
    }

    _connectedConsuls.forEach(function (conn, idx) {
      var groupId = 'consulGroup_' + idx;
      var shortUrl = _shortenConsulUrl(conn.url);
      var alive = conn.alive !== false;

      var item = document.createElement('div');
      item.className = 'accordion-item' + (alive ? '' : ' consul-group-down');
      item.innerHTML =
        '  <h2 class="accordion-header">' +
        '    <button class="accordion-button" type="button"' +
        '            data-bs-toggle="collapse" data-bs-target="#' + groupId + '"' +
        '            aria-expanded="true">' +
        '      <i class="bi ' + (alive ? 'bi-compass' : 'bi-plug') + ' me-2"></i>' +
        '      <span class="me-2">' + _escapeHtml(shortUrl) + '</span>' +
        (alive && conn.leader
          ? '<span class="badge bg-secondary me-1">' + _escapeHtml(conn.leader) + '</span>'
          : '') +
        (alive
          ? '<span class="badge bg-info">' + conn.services.length + '</span>'
          : '<span class="badge bg-danger">unreachable</span>') +
        '    </button>' +
        '  </h2>' +
        '  <div id="' + groupId + '" class="accordion-collapse collapse show">' +
        '    <div class="accordion-body p-0">' +
        '      <ul class="list-group list-group-flush"></ul>' +
        '    </div>' +
        '  </div>';
      container.appendChild(item);

      var list = item.querySelector('ul.list-group');

      if (!alive) {
        list.innerHTML =
          '<li class="list-group-item sidebar-empty-row">' +
          '  <i class="bi bi-exclamation-triangle me-1"></i>' +
          '  <em>Consul is unreachable</em>' +
          (conn.lastError
            ? '<div class="small text-muted mt-1">' + _escapeHtml(conn.lastError) + '</div>'
            : '') +
          '</li>';
        return;
      }

      if (conn.services.length === 0) {
        list.innerHTML =
          '<li class="list-group-item sidebar-empty-row">' +
          '  <em>No services registered yet.</em>' +
          '</li>';
        return;
      }

      conn.services.forEach(function (svc) {
        var row = document.createElement('li');
        row.className = 'list-group-item';
        row.setAttribute('data-service-name', svc.name);

        var status = svc.status || { kind: 'unknown', label: 'unknown' };

        // Wrap in a single block child so the two lines stack vertically
        // inside the flex row of .list-group-item.
        row.innerHTML =
          '<div class="svc-row">' +
          '  <div class="svc-name">' +
          '    <span class="svc-status svc-status-' + status.kind + '"' +
          '          title="' + _escapeHtml(status.label) + '"></span>' +
                 _escapeHtml(svc.name) +
          '  </div>' +
          '  <div class="svc-hint">' +
               _escapeHtml((svc.address || '?') + ':' + (svc.port || '?')) +
               (svc.tags.length
                 ? ' · ' + svc.tags.slice(0, 3).map(_escapeHtml).join(', ')
                 : '') +
          '  </div>' +
          '</div>';

        // Attach the Consul URL so the gRPC panel can route its calls
        // through the right bridge query param.
        var svcWithUrl = Object.assign({}, svc, { consulUrl: conn.url });

        row.addEventListener('click', function () {
          _showGrpcServicePanel(svcWithUrl);
          // Visual selection across all groups
          document
            .querySelectorAll('#servicesList .list-group-item.active')
            .forEach(function (el) { el.classList.remove('active'); });
          row.classList.add('active');
        });

        list.appendChild(row);
      });
    });
  }

  /**
   * Render the method panel for a selected service in #serviceContent.
   *
   * Fetches the method list via GET /api/grpc/services/{name} and builds
   * an accordion: one item per gRPC method, each with a JSON textarea
   * pre-filled from the reflected schema, a Call button, and a response
   * display area below.
   */
  function _showGrpcServicePanel(svc) {
    var content = document.getElementById('serviceContent');
    if (!content) return;

    content.innerHTML =
      '<div class="p-3">' +
      '  <div class="d-flex align-items-center mb-2">' +
      '    <h5 class="mb-0 me-2"><i class="bi bi-box me-2"></i>' + _escapeHtml(svc.name) + '</h5>' +
      '    <span class="badge bg-secondary me-1">' +
           _escapeHtml((svc.address || '?') + ':' + (svc.port || '?')) +
      '    </span>' +
      (svc.tags && svc.tags.length
        ? '<span class="badge bg-light text-dark">' +
            _escapeHtml(svc.tags.join(', ')) + '</span>'
        : '') +
      '  </div>' +
      '  <p class="text-muted small mb-3">' +
      '    <i class="bi bi-diagram-3 me-1"></i>' +
      '    Methods are discovered via gRPC server reflection ' +
      '    (or, if the server doesn&rsquo;t ship reflection, by compiling ' +
      '    local <code>.proto</code> files &mdash; set ' +
      '    <code>MB_PROTO_SEARCH_PATH</code>).' +
      '  </p>' +
      '  <div id="grpcMethodList">' +
      '    <div class="text-muted small">' +
      '      <span class="spinner-border spinner-border-sm me-2"></span>' +
      '      Loading methods from ' + _escapeHtml(svc.name) + '...' +
      '    </div>' +
      '  </div>' +
      '</div>';

    // Per-service proto path (typed by the user when reflection +
    // MB_PROTO_SEARCH_PATH both fail).  Persisted in sessionStorage so
    // it survives sidebar navigation but not a full reload.
    var protoPath = _getStoredProtoPath(svc.name);
    svc.protoPath = protoPath;

    MM.grpcClient.getServiceMethods(svc.name, svc.consulUrl, protoPath)
      .then(function (data) {
        _renderGrpcMethods(svc, data);
      })
      .catch(function (err) {
        var target = document.getElementById('grpcMethodList');
        if (target) {
          target.innerHTML =
            '<div class="alert alert-danger">' +
            '  <strong>Failed to load methods:</strong> ' +
            _escapeHtml(err.message || err) +
            '</div>' +
            _renderProtoPathForm(svc);
          _wireProtoPathForm(svc);
        }
      });
  }

  // ---- Proto-path override (for servers without gRPC reflection) -----

  function _protoPathStorageKey(consulName) {
    return 'mm_proto_path_' + consulName;
  }
  function _getStoredProtoPath(consulName) {
    try { return sessionStorage.getItem(_protoPathStorageKey(consulName)) || ''; }
    catch (e) { return ''; }
  }
  function _setStoredProtoPath(consulName, value) {
    try {
      if (value) sessionStorage.setItem(_protoPathStorageKey(consulName), value);
      else       sessionStorage.removeItem(_protoPathStorageKey(consulName));
    } catch (e) { /* private mode etc. */ }
  }

  /**
   * Render an inline form letting the user supply a folder containing
   * the service's .proto file, used as an extra search path for the
   * bridge's LocalProtoClient fallback when reflection + the env var
   * search paths both came up empty.
   *
   * Returned as an HTML fragment; caller is responsible for injecting
   * it into the DOM and then calling _wireProtoPathForm(svc).
   */
  function _renderProtoPathForm(svc) {
    var current = _getStoredProtoPath(svc.name);
    return '' +
      '<div class="card mt-3 mb-2">' +
      '  <div class="card-body py-3">' +
      '    <div class="mb-2">' +
      '      <i class="bi bi-folder2-open me-1"></i>' +
      '      <strong>Provide a <code>.proto</code> folder</strong>' +
      '    </div>' +
      '    <p class="small text-muted mb-2">' +
      '      The bridge will compile every <code>*.proto</code> under this folder ' +
      '      (recursively) and use the result to discover + invoke methods on ' +
      '      this service.  Persisted for the rest of this browser session.' +
      '    </p>' +
      '    <div class="input-group input-group-sm">' +
      '      <span class="input-group-text"><i class="bi bi-folder me-1"></i>Folder path</span>' +
      '      <input type="text" class="form-control" id="grpcProtoPathInput"' +
      '             value="' + _escapeHtml(current) + '"' +
      '             placeholder="e.g. D:\\Project\\.\\examples\\PowerDeviceService\\proto"' +
      '             spellcheck="false">' +
      '      <button class="btn btn-primary" id="grpcProtoPathApply" type="button">' +
      '        <i class="bi bi-arrow-repeat me-1"></i>Use this path' +
      '      </button>' +
      '      <button class="btn btn-outline-secondary" id="grpcProtoPathClear" type="button"' +
      (current ? '' : ' disabled') + '>' +
      '        Clear' +
      '      </button>' +
      '    </div>' +
      '    <p class="small text-muted mt-2 mb-0">' +
      '      Tip: a permanent fix is either rebuilding the server with ' +
      '      <code>grpc++_reflection</code> linked, or setting ' +
      '      <code>MB_PROTO_SEARCH_PATH</code> in the bridge environment.' +
      '    </p>' +
      '  </div>' +
      '</div>';
  }

  function _wireProtoPathForm(svc) {
    var input = document.getElementById('grpcProtoPathInput');
    var apply = document.getElementById('grpcProtoPathApply');
    var clear = document.getElementById('grpcProtoPathClear');
    if (!input || !apply) return;

    function submit(value) {
      _setStoredProtoPath(svc.name, value);
      svc.protoPath = value;
      // Re-render with a spinner, then re-fetch.
      var target = document.getElementById('grpcMethodList');
      if (target) {
        target.innerHTML =
          '<div class="text-muted small">' +
          '  <span class="spinner-border spinner-border-sm me-2"></span>' +
          '  Re-discovering methods using ' + _escapeHtml(value || '(default search paths)') + '...' +
          '</div>';
      }
      MM.grpcClient.getServiceMethods(svc.name, svc.consulUrl, value)
        .then(function (data) { _renderGrpcMethods(svc, data); })
        .catch(function (err) {
          var t = document.getElementById('grpcMethodList');
          if (t) {
            t.innerHTML =
              '<div class="alert alert-danger">' +
              '  <strong>Still failed:</strong> ' +
              _escapeHtml(err.message || err) +
              '</div>' +
              _renderProtoPathForm(svc);
            _wireProtoPathForm(svc);
          }
        });
    }

    apply.addEventListener('click', function () { submit(input.value.trim()); });
    input.addEventListener('keydown', function (e) {
      if (e.key === 'Enter') { e.preventDefault(); submit(input.value.trim()); }
    });
    if (clear) {
      clear.addEventListener('click', function () {
        input.value = '';
        submit('');
      });
    }
  }

  function _renderGrpcMethods(svc, data) {
    var target = document.getElementById('grpcMethodList');
    if (!target) return;

    if (data && data.error) {
      // Reflection failed AND the bridge's local-proto fallback found
      // nothing.  Render the proto-path input so the user can point us
      // at the right folder without restarting the bridge.
      var needsProtoPath = /Reflection unavailable|no \.proto files matched/i
                              .test(data.error);
      target.innerHTML =
        '<div class="alert alert-danger">' + _escapeHtml(data.error) + '</div>' +
        (needsProtoPath ? _renderProtoPathForm(svc) : '');
      if (needsProtoPath) _wireProtoPathForm(svc);
      return;
    }

    var services = (data && data.grpc_services) || [];
    if (services.length === 0) {
      target.innerHTML =
        '<div class="alert alert-warning">No gRPC services found at ' +
        _escapeHtml(data.target || '') + '.</div>';
      return;
    }

    var html = '';
    // Banner when the bridge fell back to compiling local .proto files
    // because the server didn't ship gRPC reflection (e.g. vcpkg's grpc
    // port without the reflection feature).  Calls still work — the
    // bridge built the descriptor pool from disk.
    var src = data && data.discovery_source;
    if (src && src.indexOf('local_proto:') === 0) {
      var paths = src.substring('local_proto:'.length);
      html += '<div class="alert alert-info py-2 small mb-3">' +
              '  <i class="bi bi-info-circle me-1"></i>' +
              '  <strong>Reflection unavailable on the server.</strong>' +
              '  Methods discovered by compiling <code>.proto</code> files from ' +
              '  <code>' + _escapeHtml(paths) + '</code>.' +
              '  To enable server-side reflection, rebuild with ' +
              '  <code>grpc++_reflection</code> linked into the runtime.' +
              '  <span class="ms-2">' +
              '    <a href="#" id="grpcShowProtoForm">Override proto path</a>' +
              '  </span>' +
              '</div>' +
              '<div id="grpcProtoFormSlot"></div>';
    }

    services.forEach(function (s, si) {
      if (s.error) {
        html += '<div class="alert alert-warning">' +
                '<strong>' + _escapeHtml(s.name) + '</strong>: ' +
                _escapeHtml(s.error) + '</div>';
        return;
      }
      html += '<div class="mb-3">' +
              '  <div class="small text-muted mb-1"><i class="bi bi-diagram-3 me-1"></i>' +
              _escapeHtml(s.name) +
              '  </div>' +
              '  <div class="accordion" id="grpcAcc_' + si + '">';

      (s.methods || []).forEach(function (m, mi) {
        var itemId = 'grpcMethod_' + si + '_' + mi;
        var bodyId = itemId + '_body';
        var textareaId = itemId + '_json';
        var resultId = itemId + '_result';
        var streaming = m.client_streaming || m.server_streaming;

        var streamBadge = '';
        if (m.client_streaming && m.server_streaming) {
          streamBadge = '<span class="badge bg-warning text-dark ms-2">bidi stream</span>';
        } else if (m.client_streaming) {
          streamBadge = '<span class="badge bg-warning text-dark ms-2">client stream</span>';
        } else if (m.server_streaming) {
          streamBadge = '<span class="badge bg-warning text-dark ms-2">server stream</span>';
        }

        var skeleton = '{}';
        try { skeleton = JSON.stringify(m.input_skeleton || {}, null, 2); }
        catch (e) {}

        var fieldsHtml = (m.input_fields || []).map(function (f) {
          var repeat = (f.label === 'repeated') ? '[]' : '';
          var t = _escapeHtml(f.type + repeat);
          return '<span class="badge bg-light text-dark me-1 mb-1">' +
                 _escapeHtml(f.name) + ': ' + t + '</span>';
        }).join('');

        // Disable Call only for client/bidi streaming.  Server streaming is
        // collected server-side and returned when the stream ends.
        var unsupported = m.client_streaming;
        var btnLabel = m.server_streaming ? 'Collect stream' : 'Call';

        html +=
          '<div class="accordion-item">' +
          '  <h2 class="accordion-header">' +
          '    <button class="accordion-button collapsed" type="button"' +
          '            data-bs-toggle="collapse" data-bs-target="#' + bodyId + '">' +
          '      <code class="me-2">' + _escapeHtml(m.name) + '</code>' +
          '      <span class="small text-muted">' +
                   _escapeHtml(m.input_type) + ' → ' + _escapeHtml(m.output_type) +
          '      </span>' +
                 streamBadge +
          '    </button>' +
          '  </h2>' +
          '  <div id="' + bodyId + '" class="accordion-collapse collapse"' +
          '       data-bs-parent="#grpcAcc_' + si + '">' +
          '    <div class="accordion-body">' +
          (fieldsHtml
            ? '<div class="mb-2">' + fieldsHtml + '</div>'
            : '') +
          (m.server_streaming
            ? '<div class="small text-muted mb-2"><i class="bi bi-info-circle me-1"></i>' +
              'Server-streaming RPC — up to 100 events or 15 seconds are collected, ' +
              'then the stream is cancelled.</div>'
            : '') +
          '      <label class="form-label small mb-1">Request JSON</label>' +
          '      <textarea id="' + textareaId + '" class="form-control mb-2" rows="8" ' +
          '        style="font-family:Consolas,monospace;font-size:12px;" ' +
          '        spellcheck="false">' + _escapeHtml(skeleton) + '</textarea>' +
          '      <button class="btn btn-sm btn-primary grpc-call-btn"' +
          (unsupported ? ' disabled title="Client-streaming RPCs are not supported"' : '') +
          '              data-svc="' + _escapeHtml(svc.name) + '"' +
          '              data-consul-url="' + _escapeHtml(svc.consulUrl || '') + '"' +
          '              data-grpc-svc="' + _escapeHtml(s.name) + '"' +
          '              data-method="' + _escapeHtml(m.name) + '"' +
          '              data-textarea="' + textareaId + '"' +
          '              data-result="' + resultId + '">' +
          '        <i class="bi bi-play-fill me-1"></i>' + btnLabel +
          '      </button>' +
          '      <div id="' + resultId + '" class="mt-2 small"></div>' +
          '    </div>' +
          '  </div>' +
          '</div>';
      });

      html += '  </div>' +
              '</div>';
    });

    target.innerHTML = html;

    // "Override proto path" link in the local-proto fallback banner —
    // reveals the same form that appears on hard failures.
    var showLink = document.getElementById('grpcShowProtoForm');
    var slot     = document.getElementById('grpcProtoFormSlot');
    if (showLink && slot) {
      showLink.addEventListener('click', function (e) {
        e.preventDefault();
        if (!slot.innerHTML) {
          slot.innerHTML = _renderProtoPathForm(svc);
          _wireProtoPathForm(svc);
          showLink.style.display = 'none';
        }
      });
    }

    // Wire all Call buttons.
    target.querySelectorAll('.grpc-call-btn').forEach(function (btn) {
      btn.addEventListener('click', function () {
        var consulName = btn.getAttribute('data-svc');
        var consulUrl  = btn.getAttribute('data-consul-url') || '';
        var grpcSvc = btn.getAttribute('data-grpc-svc');
        var method = btn.getAttribute('data-method');
        var textarea = document.getElementById(btn.getAttribute('data-textarea'));
        var resultEl = document.getElementById(btn.getAttribute('data-result'));

        var argsJson = textarea ? textarea.value : '{}';

        if (resultEl) {
          resultEl.className = 'mt-2 small alert alert-info py-2';
          resultEl.innerHTML =
            '<span class="spinner-border spinner-border-sm me-1"></span>Calling...';
        }
        btn.disabled = true;

        MM.grpcClient.callMethod({
          consulName: consulName,
          consulUrl:  consulUrl,
          grpcService: grpcSvc,
          method: method,
          argsJson: argsJson,
          // svc.protoPath is set by _showGrpcServicePanel from
          // sessionStorage; falsy when reflection works server-side.
          protoPath: svc && svc.protoPath ? svc.protoPath : ''
        }).then(function (data) {
          if (!resultEl) return;
          if (data.ok) {
            if (data.streaming) {
              var events = data.events || [];
              var count = events.length;
              var header =
                '<strong>Stream collected ' + count + ' event' +
                (count === 1 ? '' : 's') +
                (data.truncated ? ' (truncated)' : '') + ':</strong>';

              if (count === 0) {
                resultEl.className = 'mt-2 small alert alert-warning py-2';
                resultEl.innerHTML = header + ' (no events received)';
                return;
              }

              // Render each event as an indexed JSON block.
              var body = events.map(function (ev, i) {
                var pretty = '';
                try { pretty = JSON.stringify(ev, null, 2); }
                catch (e) { pretty = String(ev); }
                return '<div class="small text-muted mt-1">#' + i + '</div>' +
                       '<pre class="mb-0" style="white-space:pre-wrap;">' +
                       _escapeHtml(pretty) + '</pre>';
              }).join('');

              var errNote = data.error
                ? '<div class="mt-2 text-danger"><strong>Stream error:</strong> ' +
                  _escapeHtml(data.error) + '</div>'
                : '';

              resultEl.className = 'mt-2 small alert alert-success py-2';
              resultEl.innerHTML =
                header +
                '<div style="max-height:320px;overflow:auto;">' + body + '</div>' +
                errNote;
            } else {
              var pretty = '';
              try { pretty = JSON.stringify(data.result, null, 2); }
              catch (e) { pretty = String(data.result); }
              resultEl.className = 'mt-2 small alert alert-success py-2';
              resultEl.innerHTML =
                '<strong>Response:</strong>' +
                '<pre class="mb-0 mt-1" style="white-space:pre-wrap;">' +
                _escapeHtml(pretty) + '</pre>';
            }
          } else {
            resultEl.className = 'mt-2 small alert alert-danger py-2';
            resultEl.innerHTML =
              '<strong>Error:</strong> ' + _escapeHtml(data.error || 'Unknown');
          }
        }).catch(function (err) {
          if (!resultEl) return;
          resultEl.className = 'mt-2 small alert alert-danger py-2';
          resultEl.innerHTML =
            '<strong>Error:</strong> ' + _escapeHtml(err.message || err);
        }).finally(function () {
          btn.disabled = false;
        });
      });
    });
  }

  function _escapeHtml(s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  }

  // Render the initial empty sidebar state + any chips from localStorage.
  _renderAllConnectedConsuls();

  // Expose the multi-Consul connection list so other modules (notably
  // ConsulDashboard) can check whether any Consul is already connected
  // without needing to duplicate the state machine.
  MM.getConnectedConsuls = function () {
    return _connectedConsuls.slice();   // defensive copy
  };

  // --------------------------------------------------------------------
  // Periodic refresh of connected Consuls
  // --------------------------------------------------------------------
  //
  // Each connection is re-probed every 10 seconds so chips and sidebar
  // groups reflect the live state:
  //   - If a Consul becomes unreachable (agent killed, bridge down),
  //     the chip + sidebar group fade to gray and show "unreachable".
  //   - If services come and go, the sidebar rows appear/disappear
  //     without a manual refresh.
  //   - Auto-recovers when a down Consul comes back.

  var CONSUL_POLL_INTERVAL_MS = 10000;
  var _consulPollTimer = null;

  function _sameServices(a, b) {
    // Quick deep-equal for the list of service summaries we render.
    if (!Array.isArray(a) || !Array.isArray(b)) return false;
    if (a.length !== b.length) return false;
    for (var i = 0; i < a.length; i++) {
      var x = a[i], y = b[i];
      if (!x || !y) return false;
      if (x.name !== y.name || x.address !== y.address ||
          x.port !== y.port || x.instances !== y.instances) return false;
      // Status kind is the most likely field to change.
      var sx = (x.status && x.status.kind) || '';
      var sy = (y.status && y.status.kind) || '';
      if (sx !== sy) return false;
    }
    return true;
  }

  function _refreshConsul(conn) {
    // Re-run the same fetch used by initial connect, but tolerate
    // errors — on failure we mark the connection unreachable instead
    // of throwing.
    return _connectConsulUrl(conn.url)
      .then(function (fresh) {
        var changed = !conn.alive || conn.leader !== fresh.leader ||
                      !_sameServices(conn.services, fresh.services);
        conn.alive = true;
        conn.leader = fresh.leader;
        conn.services = fresh.services;
        delete conn.lastError;
        return changed;
      })
      .catch(function (err) {
        var wasDown = conn.alive === false;
        conn.alive = false;
        conn.lastError = (err && err.message) || String(err);
        conn.services = [];   // hide services of an unreachable cluster
        return !wasDown;  // changed if it was previously up
      });
  }

  function _pollConnectedConsuls() {
    if (_connectedConsuls.length === 0) return;
    Promise.all(_connectedConsuls.map(_refreshConsul))
      .then(function (flags) {
        if (flags.some(Boolean)) {
          _renderConsulChips();
          _renderAllConnectedConsuls();
        }
      });
  }

  function _startConsulPolling() {
    if (_consulPollTimer) return;
    _consulPollTimer = setInterval(_pollConnectedConsuls, CONSUL_POLL_INTERVAL_MS);
  }

  _startConsulPolling();

  // When the bridge goes down/up, poll immediately so the UI reacts
  // within a second instead of waiting up to 10s for the next tick.
  window.addEventListener('mm:bridge-state', function () {
    setTimeout(_pollConnectedConsuls, 200);
  });

  // Auto-reconnect to every Consul URL saved from a previous session.
  // Wait briefly so the bridge has time to probe first (and so polling
  // from InfraStatus doesn't race us).
  (function _autoReconnectConsuls() {
    var urls = _loadSavedConsulUrls();
    if (!urls.length) return;
    setTimeout(function () {
      urls.forEach(function (url) {
        // Skip duplicates (in case user also had connections pending)
        if (_connectedConsuls.find(function (c) { return c.url === url; })) return;
        _connectConsulUrl(url)
          .then(function (conn) {
            conn.alive = true;
            _connectedConsuls.push(conn);
            _renderConsulChips();
            _renderAllConnectedConsuls();
          })
          .catch(function (err) {
            // Still add a placeholder entry marked unreachable so the
            // chip is visible; the poll will recover it if Consul
            // comes back.
            _connectedConsuls.push({
              url: url,
              leader: '',
              services: [],
              alive: false,
              lastError: (err && err.message) || String(err)
            });
            _renderConsulChips();
            _renderAllConnectedConsuls();
            console.warn('[app] Consul auto-reconnect failed for', url, err);
          });
      });
    }, 1500);
  })();

  document.getElementById('btnLoginSubmit').addEventListener('click', function () {
    onLoginSubmit();
  });

  // Sidebar search filter — traverses 3-level hierarchy (broker > group > service)
  document.getElementById('searchText').addEventListener('input', function () {
    var query = this.value.toLowerCase().trim();
    var brokerSections = document.querySelectorAll('#' + DIV_NAME.SERVICE_LIST_DIV + ' > .broker-section');

    // If no broker sections exist yet (legacy/empty state), fall back to old behavior
    if (brokerSections.length === 0) {
      var accordionItems = document.querySelectorAll('#' + DIV_NAME.SERVICE_LIST_DIV + ' > .accordion-item');
      accordionItems.forEach(function (section) {
        var listItems = section.querySelectorAll('.list-group-item');
        var visibleCount = 0;
        listItems.forEach(function (item) {
          var serviceName = (item.getAttribute('data-service-name') || '').toLowerCase();
          var label = (item.textContent || '').toLowerCase();
          var match = query === '' || serviceName.indexOf(query) !== -1 || label.indexOf(query) !== -1;
          item.style.display = match ? '' : 'none';
          if (match) visibleCount++;
        });
        section.style.display = visibleCount > 0 ? '' : 'none';
        if (query !== '' && visibleCount > 0) {
          var collapse = section.querySelector('.accordion-collapse');
          if (collapse && !collapse.classList.contains('show')) collapse.classList.add('show');
        }
      });
      return;
    }

    brokerSections.forEach(function (brokerSection) {
      var brokerVisibleCount = 0;
      var groups = brokerSection.querySelectorAll('.accordion-item');

      groups.forEach(function (group) {
        var listItems = group.querySelectorAll('.list-group-item');
        var groupVisibleCount = 0;

        listItems.forEach(function (item) {
          var serviceName = (item.getAttribute('data-service-name') || '').toLowerCase();
          var label = (item.textContent || '').toLowerCase();
          var match = query === '' || serviceName.indexOf(query) !== -1 || label.indexOf(query) !== -1;
          item.style.display = match ? '' : 'none';
          if (match) groupVisibleCount++;
        });

        group.style.display = groupVisibleCount > 0 ? '' : 'none';
        brokerVisibleCount += groupVisibleCount;

        // Auto-expand groups that have matches when searching
        if (query !== '' && groupVisibleCount > 0) {
          var collapse = group.querySelector('.accordion-collapse');
          if (collapse && !collapse.classList.contains('show')) collapse.classList.add('show');
        }
      });

      // Hide entire broker section if no items match
      brokerSection.style.display = brokerVisibleCount > 0 ? '' : 'none';
    });
  });

  // Auto-reconnect from sessionStorage on page refresh
  try {
    var savedConnections = loadPersistedConnections();
    if (savedConnections.length > 0) {
      console.log('[app] Auto-reconnecting', savedConnections.length, 'broker(s) from saved session...');
      savedConnections.forEach(function (saved) {
        if (MM.connections[saved.brokerUrl]) return; // skip duplicates
        addConnection(saved.brokerUrl, saved.routingKey);
        addAliasServiceForBroker(saved.brokerUrl, saved.routingKey);
        requestServicesInforForBroker(saved.brokerUrl);
      });
      updateBrokerHeaders();
    }
  } catch (e) { /* sessionStorage unavailable */ }

  /************************************************************
   *          Functions: Logic and Interaction with Services   *
   ************************************************************/

  /**
   * Open the login modal to connect to the broker.
   */
  function connect() {
    if (!loginModal) {
      loginModal = new bootstrap.Modal(document.getElementById('loginModal'));
    }
    loginModal.show();
  }

  /**
   * Handle the login form submission from the modal.
   */
  function onLoginSubmit() {
    var brokerUrl = document.getElementById('brokerUrlInput').value.trim();
    var routingKey = document.getElementById('routingKeyInput').value.trim();

    if (!brokerUrl) {
      showToast('Validation Error', 'Broker URL is required.', 'danger');
      return;
    }

    if (loginModal) {
      loginModal.hide();
    }

    // Duplicate-connection check
    if (MM.connections[brokerUrl]) {
      showToast('Already Connected', 'Already connected to ' + brokerUrl, 'warning');
      return;
    }

    // Handle fleet API URL from advanced settings
    var fleetApiUrlInput = document.getElementById('fleetApiUrlInput');
    var fleetApiUrl = fleetApiUrlInput ? fleetApiUrlInput.value.trim() : '';
    if (fleetApiUrl && MM.fleetClient) {
      MM.fleetClient.configure(fleetApiUrl)
        .then(function () {
          try { localStorage.setItem('mm_fleet_api_url', fleetApiUrl); } catch (e) {}
        })
        .catch(function (err) {
          console.warn('[app] Failed to configure fleet URL:', err);
        });
    }

    showToast('Connecting', 'Connecting to broker at ' + brokerUrl + '...', 'info');
    addConnection(brokerUrl, routingKey);
    addAliasServiceForBroker(brokerUrl, routingKey);
    requestServicesInforForBroker(brokerUrl);
    persistConnections();
    updateBrokerHeaders();
  }

  /**
   * Add the Alias service GUI entry for a specific broker.
   *
   * @param {string} brokerUrl - The broker address.
   * @param {string} routingKey - The registry routing key for this broker.
   */
  function addAliasServiceForBroker(brokerUrl, routingKey) {
    var aliasServiceData = [
      {
        title: 'Alias Manager',
        contentId: 'content-accordion-alias',
        items: [
          {
            label: 'Alias',
            iconSrc: IMAGE_PATH.READY,
            serviceName: 'ServiceAlias'
          }
        ]
      }
    ];

    createAccordionItems(aliasServiceData, brokerUrl);
    if (!MM.servicesInfor) {
      MM.servicesInfor = {};
    }

    MM.servicesInfor.ServiceAlias = {
      description: 'Service to alias specific service api to an api name.',
      group: '',
      gui_support: true,
      methods: [],
      name: 'ServiceRegistry',
      routing_key: '',
      shortdesc: 'Alias service',
      tag: '',
      version: '1.0.0'
    };
  }

  // Backward-compat wrapper
  function addAliasService() {
    var firstBroker = Object.keys(MM.connections)[0] || MM.brokerUrl;
    var routingKey = firstBroker && MM.connections[firstBroker] ? MM.connections[firstBroker].routingKey : MM.routingKey;
    addAliasServiceForBroker(firstBroker, routingKey);
  }

  /**
   * Disconnect a single broker and remove its sidebar section.
   *
   * @param {string} brokerUrl - The broker address to disconnect.
   */
  function disconnectBroker(brokerUrl) {
    // Remove DOM section
    var servicesList = document.getElementById(DIV_NAME.SERVICE_LIST_DIV);
    var section = servicesList.querySelector('.broker-section[data-broker-url="' + brokerUrl + '"]');
    if (section) {
      // If active service was on this broker, clear content panel
      var activeItem = section.querySelector('.list-group-item.active');
      if (activeItem) {
        _deactivateCurrentPanel();
        clearServiceContent();
        MM.activeBrokerUrl = null;
      }
      section.remove();
    }

    removeConnection(brokerUrl);
    updateConnectionBadge();
    persistConnections();
    updateBrokerHeaders();

    // If no connections remain, reset legacy globals
    if (getConnectionCount() === 0) {
      MM.brokerUrl = null;
      MM.routingKey = null;
      MM.servicesInfor = null;
      MM.serviceClient.disconnect();
    }
  }

  /**
   * Disconnect all brokers.
   */
  function disconnect() {
    var brokerUrls = Object.keys(MM.connections);
    brokerUrls.forEach(function (url) {
      disconnectBroker(url);
    });
    unloadFunction = null;
    clearServiceList();
    clearServiceContent();
    try {
      sessionStorage.removeItem('mm_connections');
      sessionStorage.removeItem('mm_brokerUrl');
      sessionStorage.removeItem('mm_routingKey');
    } catch (e) { /* sessionStorage unavailable */ }
  }

  /**
   * Set Registry Service connection info (legacy, updates active broker alias).
   *
   * @param {object} registryData - The information of the Registry Service.
   */
  function setRegistryServiceInfo(registryData) {
    MM.brokerUrl = registryData.brokerUrl;
    MM.routingKey = registryData.routingKey;
    MM.activeBrokerUrl = registryData.brokerUrl;
  }

  /**
   * Extracts and structures services information from parsed JSON data.
   *
   * @param {object} data - Parsed JSON data containing services information.
   * @returns {Array} - A structured representation of services information.
   */
  function extractServicesInformation(data) {
    var accordionData = Object.values(data).reduce(function (acc, service) {
      if (HIDDEN_SERVICES.indexOf(service.name) !== -1) return acc;
      var group = service.group || DEFAULT_GROUP;
      var existingItem = acc.find(function (item) { return item.title === group; });
      var newItem = {
        label: service.name,
        iconSrc: IMAGE_PATH.READY,
        serviceName: service.name,
        downloadable: !!service.downloadable
      };

      if (!existingItem) {
        acc.push({
          title: group,
          contentId: 'content-' + group.replace(/ /g, '-').toLowerCase(),
          items: [newItem]
        });
      } else {
        existingItem.items.push(newItem);
      }

      return acc;
    }, []);

    console.log(accordionData);
    return accordionData;
  }

  /**
   * Check if service GUI resources exist and are up-to-date; download if needed.
   * Uses a checksum from the service to detect file changes, with a fallback
   * to simple folder-existence checks for services that lack checksum support.
   */
  function checkAndGetTheServiceGUIResources(serviceName, callbackFunc) {
    callbackFunc = callbackFunc || null;
    var serviceVersion = MM.servicesInfor[serviceName].version;
    var folderPath = SERVICES_GUI_FOLDER + '/' + serviceName + serviceVersion;
    var routingKey = MM.servicesInfor[serviceName].routing_key;

    // Local-only services (no routing key) — skip checksum, just check folder
    if (!routingKey) {
      _checkGUIFolderExists(serviceName, folderPath, callbackFunc);
      return;
    }

    // Request remote checksum, then compare against local files on disk.
    // No localStorage/sessionStorage needed — the truth is on disk.
    var checksumRequest = { method: 'svc_api_get_gui_checksum', args: null };
    requestService(checksumRequest, SERVICES_EXCHANGE_NAME, routingKey)
      .then(function (data) {
        var remoteChecksum = data.result_data;

        var _doDownload = function () {
          var onSuccess = function () { if (callbackFunc) callbackFunc(); };
          if (window.electronAPI) {
            requestServiceGUIResources(serviceName, folderPath, onSuccess);
          } else {
            requestServiceGUIResourcesBrowser(serviceName, folderPath, onSuccess);
          }
        };

        // Compute checksum from local files and compare with remote
        _computeLocalChecksum(folderPath, function (localChecksum) {
          if (localChecksum && localChecksum === remoteChecksum) {
            console.log('GUI checksum matches for', serviceName, '- using cached files');
            if (callbackFunc) callbackFunc();
          } else if (localChecksum && localChecksum !== remoteChecksum) {
            console.log('GUI checksum changed for', serviceName, '- downloading');
            _doDownload();
          } else {
            // localChecksum is null: either folder missing or checksum not
            // computable (browser mode). Check if folder exists on disk —
            // if yes, assume files are current and skip the download.
            _checkGUIFolderExists(serviceName, folderPath, callbackFunc);
          }
        });
      })
      .catch(function (error) {
        // Checksum API not available — fall back to folder existence check
        console.warn('GUI checksum not available for', serviceName, ', falling back to folder check');
        _checkGUIFolderExists(serviceName, folderPath, callbackFunc);
      });
  }

  /**
   * Lightweight folder-existence check (calls back with boolean).
   * Used by checksum logic to verify files are actually on disk.
   */
  /**
   * Compute MD5 checksum of local GUI files on disk.
   * Mirrors Python ServiceBase.svc_api_get_gui_checksum() algorithm.
   * Calls back with the hex-digest string, or null if folder doesn't exist.
   *
   * Electron: uses electronAPI.computeGuiChecksum() (Node crypto).
   * Browser:  uses SubtleCrypto (Web Crypto API).
   */
  function _computeLocalChecksum(folderPath, callback) {
    if (window.electronAPI && window.electronAPI.computeGuiChecksum) {
      window.electronAPI.computeGuiChecksum(folderPath)
        .then(function (checksum) { callback(checksum); })
        .catch(function () { callback(null); });
    } else {
      // Browser mode: fetch file list, then hash each file.
      // Requires FastAPI to serve directory listings.
      _computeLocalChecksumBrowser(folderPath, callback);
    }
  }

  /**
   * Browser-mode local checksum: read files via fetch and hash with SubtleCrypto.
   * Falls back to null if listing or hashing fails.
   */
  function _computeLocalChecksumBrowser(folderPath, callback) {
    // Try to get file listing from the folder
    fetch(folderPath + '/')
      .then(function (r) {
        if (!r.ok) { callback(null); return Promise.reject('no folder'); }
        return r.text();
      })
      .then(function (html) {
        // Parse file links from directory listing (FastAPI serves <a href="file">)
        var parser = new DOMParser();
        var doc = parser.parseFromString(html, 'text/html');
        var links = Array.from(doc.querySelectorAll('a[href]'));
        var files = links
          .map(function (a) { return decodeURIComponent(a.getAttribute('href')); })
          .filter(function (h) { return h && !h.startsWith('/') && !h.startsWith('..'); })
          .sort();

        if (files.length === 0) { callback(null); return; }

        // Fetch all files as ArrayBuffers
        var fetches = files.map(function (f) {
          return fetch(folderPath + '/' + f).then(function (r) {
            return r.ok ? r.arrayBuffer() : null;
          }).catch(function () { return null; });
        });

        Promise.all(fetches).then(function (buffers) {
          // Concatenate (relPath + content) for each file — same as Python algo
          var encoder = new TextEncoder();
          var totalLen = 0;
          var parts = [];
          for (var i = 0; i < files.length; i++) {
            if (!buffers[i]) continue;
            var pathBytes = encoder.encode(files[i]);
            parts.push(pathBytes);
            parts.push(new Uint8Array(buffers[i]));
            totalLen += pathBytes.length + buffers[i].byteLength;
          }
          var combined = new Uint8Array(totalLen);
          var offset = 0;
          for (var j = 0; j < parts.length; j++) {
            combined.set(parts[j], offset);
            offset += parts[j].length;
          }

          // SubtleCrypto doesn't support MD5. Use a simple MD5 or fall back.
          // If crypto.subtle is available, we can't use it for MD5.
          // Fall back to folder-exists check (checksum not computable in browser).
          callback(null);
        });
      })
      .catch(function () { callback(null); });
  }

  /**
   * Fallback: check folder existence only (for services without checksum support).
   */
  function _checkGUIFolderExists(serviceName, folderPath, callbackFunc) {
    if (typeof window !== 'undefined' && window.electronAPI) {
      window.electronAPI.folderExists(folderPath)
        .then(function (exists) {
          if (exists) {
            if (callbackFunc) callbackFunc();
          } else {
            requestServiceGUIResources(serviceName, folderPath, callbackFunc);
          }
        })
        .catch(function () {
          requestServiceGUIResources(serviceName, folderPath, callbackFunc);
        });
    } else {
      var testUrl = folderPath + '/' + serviceName + '.html';
      fetch(testUrl, { method: 'HEAD' })
        .then(function (response) {
          if (response.ok) {
            if (callbackFunc) callbackFunc();
          } else {
            requestServiceGUIResourcesBrowser(serviceName, folderPath, callbackFunc);
          }
        })
        .catch(function () {
          requestServiceGUIResourcesBrowser(serviceName, folderPath, callbackFunc);
        });
    }
  }

  /**
   * Request GUI resources download via FastAPI bridge (browser mode).
   */
  function requestServiceGUIResourcesBrowser(serviceName, folderPath, callbackFunc) {
    var apiUrl = MM.serviceClient.apiUrl;
    var routingKey = MM.servicesInfor[serviceName].routing_key;
    fetch(apiUrl + '/api/service-gui-download/' + encodeURIComponent(serviceName) + '?routing_key=' + encodeURIComponent(routingKey), {
      method: 'POST'
    })
      .then(function (response) {
        if (response.ok) {
          console.log('GUI resources downloaded for', serviceName);
          if (callbackFunc) callbackFunc();
        } else {
          console.warn('Failed to download GUI resources for', serviceName, '- showing API explorer');
          showServiceAPIExplorer(serviceName);
        }
      })
      .catch(function (error) {
        console.warn('Error downloading GUI resources:', error, '- showing API explorer');
        showServiceAPIExplorer(serviceName);
      });
  }

  /************************************************************
   *             Realtime Service Status Updates              *
   ************************************************************/

  /**
   * Subscribe to realtime service status updates for a specific broker.
   *
   * @param {string} brokerUrl - The broker to subscribe to.
   */
  function subscribeToRealtimeUpdatesForBroker(brokerUrl) {
    var conn = MM.connections[brokerUrl];
    if (!conn || conn.realtimeSubscribed) return;

    if (!window.electronAPI) {
      // Browser mode: WebSocket to FastAPI bridge (shared, broker-agnostic)
      // Only connect once; messages are dispatched to all brokers
      console.log('[app] Browser mode: connecting WebSocket for realtime updates (broker:', brokerUrl, ')');
      MM.serviceClient.onServicesUpdate(function (message) {
        handleServicesUpdateForBroker(message, brokerUrl);
      });
      if (!MM.serviceClient._wsReady && !MM.serviceClient._ws) {
        MM.serviceClient.connectUpdates().catch(function (err) {
          console.error('[app] Failed to connect WebSocket updates:', err);
        });
      }
      conn.realtimeSubscribed = true;
      return;
    }

    // Electron mode: get fanout exchange name from Registry, subscribe via AMQP
    var requestData = {
      'method': 'svc_api_get_realtime_update_exchange',
      'args': null
    };

    MM.serviceClient.setBrokerUrl(brokerUrl);
    requestService(requestData, SERVICES_EXCHANGE_NAME, conn.routingKey)
      .then(function (data) {
        var exchangeName = data.result_data;
        if (!exchangeName) {
          console.warn('[app] No realtime update exchange name received from', brokerUrl);
          return;
        }
        console.log('[app] Subscribing to realtime update exchange:', exchangeName, 'on', brokerUrl);
        MM.serviceClient.setBrokerUrl(brokerUrl);
        MM.serviceClient.subscribeToExchange(exchangeName, function (message) {
          handleServicesUpdateForBroker(message, brokerUrl);
        });
        conn.realtimeSubscribed = true;
      })
      .catch(function (error) {
        console.error('[app] Failed to get realtime update exchange from', brokerUrl, ':', error);
      });
  }

  // Legacy wrapper
  function subscribeToRealtimeUpdates() {
    if (MM.activeBrokerUrl) {
      subscribeToRealtimeUpdatesForBroker(MM.activeBrokerUrl);
    }
  }

  /**
   * Handle a services update scoped to a specific broker.
   *
   * @param {object|string} message - The services information dict or JSON string.
   * @param {string} brokerUrl - The broker this update belongs to.
   */
  function handleServicesUpdateForBroker(message, brokerUrl) {
    console.log('[app] handleServicesUpdateForBroker called for', brokerUrl);
    var updatedServices;
    if (typeof message === 'string') {
      try {
        updatedServices = JSON.parse(message);
      } catch (e) {
        console.error('[app] Failed to parse services update:', e);
        return;
      }
    } else {
      updatedServices = message;
    }

    // Detect registry shutdown sentinel
    if (updatedServices && updatedServices.__registry_shutdown__) {
      console.warn('[app] Registry shutdown detected for broker:', brokerUrl);
      showToast(
        'Registry Disconnected',
        'The Service Registry on ' + brokerUrl + ' has shut down.',
        'warning'
      );
      disconnectBroker(brokerUrl);
      return;
    }

    // Scope queries to this broker's section
    var servicesList = document.getElementById(DIV_NAME.SERVICE_LIST_DIV);
    var brokerSection = servicesList.querySelector('.broker-section[data-broker-url="' + brokerUrl + '"]');
    if (!brokerSection) return;

    var allItems = brokerSection.querySelectorAll('.list-group-item[data-service-name]');

    allItems.forEach(function (listItem) {
      var serviceName = listItem.getAttribute('data-service-name');
      if (serviceName === 'ServiceAlias') return;

      var icon = listItem.querySelector('.icon');
      if (serviceName in updatedServices) {
        if (listItem.classList.contains('service-disabled')) {
          listItem.classList.remove('service-disabled');
          if (icon) icon.src = IMAGE_PATH.READY;
          console.log('[app] Service came online:', serviceName, 'on', brokerUrl);
          showToast('Service Online', serviceName + ' is now available.', 'success');
        }
      } else {
        if (!listItem.classList.contains('service-disabled')) {
          if (listItem.classList.contains('active')) {
            listItem.classList.remove('active');
            var contentDiv = document.getElementById(DIV_NAME.SERVICE_CONTENT_DIV);
            _deactivateCurrentPanel();
            // Remove the disconnected service's cached panel
            if (_servicePanels[serviceName]) {
              if (_servicePanels[serviceName].parentNode) {
                _servicePanels[serviceName].parentNode.removeChild(_servicePanels[serviceName]);
              }
              delete _servicePanels[serviceName];
            }
            // Append placeholder as non-cached child
            var placeholder = document.createElement('div');
            placeholder.className = 'content-placeholder';
            placeholder.innerHTML =
              '<span><i class="bi bi-exclamation-triangle me-2"></i>' +
                _escapeHtml(serviceName) + ' has disconnected</span>';
            contentDiv.appendChild(placeholder);
          }
          listItem.classList.add('service-disabled');
          if (icon) icon.src = IMAGE_PATH.DISABLED;
          console.log('[app] Service went offline:', serviceName, 'on', brokerUrl);
          showToast('Service Offline', serviceName + ' is no longer available.', 'warning');
        }
      }
    });

    // Check if any new services appeared on this broker
    Object.keys(updatedServices).forEach(function (serviceName) {
      var svcInfo = updatedServices[serviceName];

      if (!brokerSection.querySelector('.list-group-item[data-service-name="' + serviceName + '"]')) {
        var newServiceData = {};
        newServiceData[serviceName] = svcInfo;
        var newItems = extractServicesInformation(newServiceData);

        // Try to append to an existing group before creating a new one.
        var added = false;
        var prefix = sanitizeBrokerId(brokerUrl) + '_';
        newItems.forEach(function (group) {
          var existingCollapse = brokerSection.querySelector('#' + prefix + group.contentId);
          if (existingCollapse) {
            var listGroup = existingCollapse.querySelector('.list-group');
            if (listGroup) {
              group.items.forEach(function (item) {
                listGroup.appendChild(_createServiceListItem(item, brokerUrl));
              });
              added = true;
            }
          }
        });

        if (!added) {
          createAccordionItems(newItems, brokerUrl);
        }

        console.log('[app] New service appeared:', serviceName, 'on', brokerUrl);
        showToast('Service Online', serviceName + ' is now available.', 'success');
      }
    });

    // Update per-broker service store and rebuild merged view
    var conn = MM.connections[brokerUrl];
    if (conn) {
      conn.services = updatedServices;
      rebuildMergedServicesInfor();
    }
    updateBrokerBadge(brokerUrl);
  }

  /**
   * Legacy wrapper for backward compat.
   */
  function handleServicesUpdate(message) {
    // Route to the active broker or first broker
    var brokerUrl = MM.activeBrokerUrl || Object.keys(MM.connections)[0];
    if (brokerUrl) {
      handleServicesUpdateForBroker(message, brokerUrl);
    }
  }

  /************************************************************
   *                  Service Request Functions               *
   ************************************************************/

  /**
   * Get all services information from Registry Service for a specific broker.
   *
   * @param {string} brokerUrl - The broker to query.
   */
  function requestServicesInforForBroker(brokerUrl) {
    var conn = MM.connections[brokerUrl];
    if (!conn) return;

    var requestData = {
      'method': 'svc_api_get_services_info',
      'args': null
    };

    // Set active broker context for the request
    setRegistryServiceInfo({ brokerUrl: brokerUrl, routingKey: conn.routingKey });

    requestService(requestData, SERVICES_EXCHANGE_NAME, conn.routingKey)
      .then(function (data) {
        console.log('Received service infor from', brokerUrl, ':', data);
        var servicesInfor = JSON.parse(data.result_data);
        conn.services = servicesInfor;
        rebuildMergedServicesInfor();
        var serviceItems = extractServicesInformation(servicesInfor);
        createAccordionItems(serviceItems, brokerUrl);
        updateConnectionBadge();
        showToast('Connected', 'Successfully connected to ' + brokerUrl, 'success');

        // Subscribe to realtime updates from this broker's Registry
        subscribeToRealtimeUpdatesForBroker(brokerUrl);
      })
      .catch(function (error) {
        console.error('Error loading data from', brokerUrl, ':', error);
        disconnectBroker(brokerUrl);
        showToast('Connection Failed', 'Could not connect to ' + brokerUrl + ': ' + (error.message || error), 'danger');
      });
  }

  /**
   * Legacy wrapper — get services info from the active broker.
   */
  function requestServicesInfor() {
    if (MM.brokerUrl && MM.connections[MM.brokerUrl]) {
      requestServicesInforForBroker(MM.brokerUrl);
    }
  }

  /**
   * Retrieves GUI resources of a service (Electron mode).
   *
   * @param {string} serviceName - The name of the service.
   * @param {string} folderPath - The path of the folder to store resources.
   * @param {Function|null} callbackFunc - Optional callback.
   */
  function requestServiceGUIResources(serviceName, folderPath, callbackFunc) {
    callbackFunc = callbackFunc || null;
    var requestData = {
      'method': 'svc_api_get_gui_files',
      'args': null
    };

    requestService(requestData, SERVICES_EXCHANGE_NAME, MM.servicesInfor[serviceName].routing_key)
      .then(function (data) {
        console.log('Received service GUI data');
        if (window.electronAPI) {
          return window.electronAPI.extractGUIZip(folderPath, data.result_data)
            .then(function () {
              console.log('GUI files extracted to', folderPath);
              if (callbackFunc) callbackFunc();
            });
        } else {
          // Fallback: browser mode should use requestServiceGUIResourcesBrowser
          if (callbackFunc) callbackFunc();
        }
      })
      .catch(function (error) {
        console.error('Error loading GUI data:', error);
        changeConnectButtonState(CONNECTION_STATUS.DISCONNECTED);
      });
  }

  /**
   * Downloads the full service source directory as a ZIP file.
   *
   * @param {string} serviceName - The name of the service to download.
   */
  function downloadServiceFiles(serviceName) {
    var serviceInfo = MM.servicesInfor[serviceName];
    if (!serviceInfo) {
      MM.showToast('Error', 'Service info not found for ' + serviceName, 'warning');
      return;
    }

    var requestData = { method: 'svc_api_get_service_files', args: null };
    var requestPromise;
    if (serviceInfo.routing_key) {
      requestPromise = requestService(requestData, SERVICES_EXCHANGE_NAME, serviceInfo.routing_key);
    } else {
      requestPromise = MM.requestServiceDirect(requestData, serviceName);
    }

    requestPromise
      .then(function (data) {
        if (!data.result_data) {
          MM.showToast('Error', 'No file data received from ' + serviceName, 'warning');
          return;
        }
        var byteChars = atob(data.result_data);
        var byteNumbers = new Array(byteChars.length);
        for (var i = 0; i < byteChars.length; i++) {
          byteNumbers[i] = byteChars.charCodeAt(i);
        }
        var byteArray = new Uint8Array(byteNumbers);
        var blob = new Blob([byteArray], { type: 'application/zip' });
        var url = URL.createObjectURL(blob);
        var a = document.createElement('a');
        a.href = url;
        a.download = serviceName + '.zip';
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
      })
      .catch(function (error) {
        console.error('Error downloading service files:', error);
        MM.showToast('Error', 'Failed to download service files: ' + error.message, 'warning');
      });
  }

  /**
   * Sends a request to a service via the shared client.
   *
   * @param {object} requestData - The JSON-formatted data to be sent.
   * @param {string} exchangeName - The name of the exchange.
   * @param {string} routingKey - The routing key for the target service.
   * @returns {Promise} A Promise that resolves with the response.
   */
  function requestService(requestData, exchangeName, routingKey) {
    var broker = resolveBrokerUrl(routingKey) || MM.brokerUrl;
    MM.serviceClient.setBrokerUrl(broker);
    return MM.serviceClient.requestService(requestData, exchangeName, routingKey);
  }

  /************************************************************
   *                  Utility Functions                       *
   ************************************************************/

  function generateUuid() {
    return Math.random().toString() +
      Math.random().toString() +
      Math.random().toString();
  }

  /************************************************************
   *               Mode Switching (Services / Fleet)          *
   ************************************************************/

  var _currentMode = 'services';
  var _helpVisible = false;
  var _helpLoaded = false;
  var _modeBeforeHelp = null;

  function switchMode(mode) {
    // If help overlay is open, close it first then switch
    if (_helpVisible) {
      _closeHelpOverlay();
    }
    if (mode === _currentMode) return;

    // Deactivate previous mode
    if (_currentMode === 'fleet') {
      deactivateFleetMode();
    } else if (_currentMode === 'creator') {
      deactivateCreatorMode();
    }

    _currentMode = mode;

    // Toggle sidebar panels
    var sidebarServices = document.getElementById('sidebarServices');
    var sidebarFleet = document.getElementById('sidebarFleet');
    var sidebarCreator = document.getElementById('sidebarCreator');
    if (sidebarServices) sidebarServices.classList.toggle('active', mode === 'services');
    if (sidebarFleet) sidebarFleet.classList.toggle('active', mode === 'fleet');
    if (sidebarCreator) sidebarCreator.classList.toggle('active', mode === 'creator');

    // Toggle content panels
    var serviceContent = document.getElementById('serviceContent');
    var fleetContent = document.getElementById('fleetContent');
    var creatorContent = document.getElementById('creatorContent');
    if (serviceContent) serviceContent.style.display = mode === 'services' ? '' : 'none';
    if (fleetContent) fleetContent.style.display = mode === 'fleet' ? '' : 'none';
    if (creatorContent) creatorContent.style.display = mode === 'creator' ? '' : 'none';

    // Toggle nav buttons
    var btnServices = document.getElementById('btnModeServices');
    var btnFleet = document.getElementById('btnModeFleet');
    var btnCreator = document.getElementById('btnModeCreator');
    if (btnServices) btnServices.classList.toggle('active', mode === 'services');
    if (btnFleet) btnFleet.classList.toggle('active', mode === 'fleet');
    if (btnCreator) btnCreator.classList.toggle('active', mode === 'creator');

    // Activate new mode
    if (mode === 'fleet') {
      activateFleetMode();
    } else if (mode === 'creator') {
      activateCreatorMode();
    }
  }

  function activateFleetMode() {
    // Only Nomad and Consul sub-tabs remain after ProcessHub removal.
    var nomadTab = document.getElementById('tabNomad');
    var consulTab = document.getElementById('tabConsul');
    var isConsulActive = consulTab && consulTab.classList.contains('active');

    if (isConsulActive) {
      _activateConsulSubTab();
    } else {
      _activateNomadSubTab();
    }

    // Wire sub-tab switch events
    if (nomadTab) {
      nomadTab._mmHandler = nomadTab._mmHandler || function () {
        _deactivateConsulSubTab();
        _activateNomadSubTab();
      };
      nomadTab.removeEventListener('shown.bs.tab', nomadTab._mmHandler);
      nomadTab.addEventListener('shown.bs.tab', nomadTab._mmHandler);
    }
    if (consulTab) {
      consulTab._mmHandler = consulTab._mmHandler || function () {
        _deactivateNomadSubTab();
        _activateConsulSubTab();
      };
      consulTab.removeEventListener('shown.bs.tab', consulTab._mmHandler);
      consulTab.addEventListener('shown.bs.tab', consulTab._mmHandler);
    }
  }

  function _showContentSpinner(containerId) {
    var container = document.getElementById(containerId);
    if (!container) return;
    container.innerHTML =
      '<div class="content-loading">' +
      '  <div class="spinner-border" role="status"></div>' +
      '  <span>Loading...</span>' +
      '</div>';
  }

  function _activateNomadSubTab() {
    if (MM.nomadDashboard) MM.nomadDashboard.activate();
  }

  function _deactivateNomadSubTab() {
    if (MM.nomadDashboard) MM.nomadDashboard.deactivate();
  }

  function _activateConsulSubTab() {
    var pane = document.getElementById('consulPane');
    if (pane && !pane.hasChildNodes()) _showContentSpinner('consulPane');
    if (MM.consulDashboard) MM.consulDashboard.activate();
  }

  function _deactivateConsulSubTab() {
    if (MM.consulDashboard) MM.consulDashboard.deactivate();
  }

  function deactivateFleetMode() {
    if (MM.nomadDashboard) MM.nomadDashboard.deactivate();
    if (MM.consulDashboard) MM.consulDashboard.deactivate();
  }

  function activateCreatorMode() {
    if (MM.serviceCreator) MM.serviceCreator.activate();
  }

  function deactivateCreatorMode() {
    if (MM.serviceCreator) MM.serviceCreator.deactivate();
  }

  // Wire mode toggle buttons
  var btnModeServices = document.getElementById('btnModeServices');
  var btnModeFleet = document.getElementById('btnModeFleet');
  if (btnModeServices) {
    btnModeServices.addEventListener('click', function () { switchMode('services'); });
  }
  if (btnModeFleet) {
    btnModeFleet.addEventListener('click', function () { switchMode('fleet'); });
  }
  var btnModeCreator = document.getElementById('btnModeCreator');
  if (btnModeCreator) {
    btnModeCreator.addEventListener('click', function () { switchMode('creator'); });
  }

  // Restore fleet URL from localStorage on page load
  try {
    var savedFleetUrl = localStorage.getItem('mm_fleet_api_url');
    if (savedFleetUrl && MM.fleetClient) {
      MM.fleetClient.configure(savedFleetUrl);
    }
  } catch (e) { /* localStorage unavailable */ }

  /************************************************************
   *               Expose functions for plugins               *
   ************************************************************/

  MM.requestService = requestService;
  MM.requestServiceDirect = function (data, queue) {
    var broker = resolveBrokerUrlForService(queue) || MM.brokerUrl;
    MM.serviceClient.setBrokerUrl(broker);
    return MM.serviceClient.requestServiceDirect(data, queue);
  };
  MM.loadContent = loadContent;
  MM.changeConnectButtonState = changeConnectButtonState;
  MM.showToast = showToast;
  MM.showConfirm = showConfirm;
  MM.showWarningDialog = showWarningDialog;
  MM.activateItemAndLoadContent = activateItemAndLoadContent;
  MM.SERVICES_EXCHANGE_NAME = SERVICES_EXCHANGE_NAME;
  MM.CONNECTION_STATUS = CONNECTION_STATUS;
  MM.SERVICES_GUI_FOLDER = SERVICES_GUI_FOLDER;

  /**
   * List files in a service GUI folder.
   * Works in both Electron (via preload) and web/FastAPI (via API) modes.
   * @param {string} folderPath - Relative path (e.g. "services/MyService1.0.0").
   * @returns {Promise<string[]>} Array of filenames.
   */
  MM.listServiceFiles = function (folderPath) {
    // Electron mode: use preload's synchronous fs.readdirSync
    if (window.electronAPI && typeof window.electronAPI.listDir === 'function') {
      return Promise.resolve(window.electronAPI.listDir(folderPath));
    }
    // Web/FastAPI mode: use list-dir API
    var apiUrl = MM.serviceClient ? MM.serviceClient.apiUrl : '';
    return fetch(apiUrl + '/api/list-dir/' + encodeURIComponent(folderPath))
      .then(function (resp) {
        if (!resp.ok) throw new Error('list-dir failed');
        return resp.json();
      })
      .then(function (data) { return data.files || []; });
  };
  MM.showServiceAPIExplorer = showServiceAPIExplorer;
  MM.showServiceHelper = showServiceHelper;
  MM.switchMode = switchMode;

  /************************************************************
   *               Help Overlay                                 *
   ************************************************************/

  function openHelp() {
    if (_helpVisible) return;
    _modeBeforeHelp = _currentMode;
    _currentMode = '__help__';
    _helpVisible = true;

    // Hide sidebar and all content panels
    var sidebar = document.querySelector('.app-sidebar');
    if (sidebar) sidebar.style.display = 'none';

    var serviceContent = document.getElementById('serviceContent');
    var fleetContent = document.getElementById('fleetContent');
    var creatorContent = document.getElementById('creatorContent');
    if (serviceContent) serviceContent.style.display = 'none';
    if (fleetContent) fleetContent.style.display = 'none';
    if (creatorContent) creatorContent.style.display = 'none';

    // Remove active from mode buttons
    var modeButtons = document.querySelectorAll('.mode-btn');
    modeButtons.forEach(function (btn) { btn.classList.remove('active'); });

    // Highlight help button
    var btnHelp = document.getElementById('btnHelp');
    if (btnHelp) btnHelp.classList.add('active');

    // Show help content
    var helpContent = document.getElementById('helpContent');
    if (helpContent) {
      helpContent.style.display = '';
      // Load HTML on first open, refresh versions every time
      if (!_helpLoaded) {
        fetch('docs/help.html')
          .then(function (res) { return res.text(); })
          .then(function (html) {
            helpContent.innerHTML = html;
            _helpLoaded = true;
            _wireHelpTOC();
            _refreshHelpVersions();
          })
          .catch(function (err) {
            helpContent.innerHTML =
              '<div style="padding:2rem;color:#e74c3c;">' +
              '<i class="bi bi-exclamation-triangle me-2"></i>Failed to load help: ' +
              err.message + '</div>';
          });
      } else {
        _refreshHelpVersions();
      }
    }
  }

  /**
   * Internal: hide help overlay and restore DOM state, but do NOT call switchMode.
   */
  function _closeHelpOverlay() {
    if (!_helpVisible) return;
    _helpVisible = false;

    var btnHelp = document.getElementById('btnHelp');
    if (btnHelp) btnHelp.classList.remove('active');

    var helpContent = document.getElementById('helpContent');
    if (helpContent) helpContent.style.display = 'none';

    // Restore sidebar
    var sidebar = document.querySelector('.app-sidebar');
    if (sidebar) sidebar.style.display = '';
  }

  function closeHelp() {
    if (!_helpVisible) return;
    var restoreMode = _modeBeforeHelp || 'services';
    _closeHelpOverlay();
    // Force switchMode by temporarily resetting _currentMode
    _currentMode = '__help__';
    switchMode(restoreMode);
  }

  function toggleHelp() {
    if (_helpVisible) {
      closeHelp();
    } else {
      openHelp();
    }
  }

  /**
   * Fetch and display version info. Called every time help is opened
   * so it picks up a bridge that started after first load.
   */
  function _refreshHelpVersions() {
    var helpContent = document.getElementById('helpContent');
    if (!helpContent) return;

    var guiVersionEl = helpContent.querySelector('#docsGuiVersion');
    var baseVersionEl = helpContent.querySelector('#docsBaseVersion');

    if (guiVersionEl && !guiVersionEl._loaded) {
      fetch('version.json')
        .then(function (res) { return res.json(); })
        .then(function (data) {
          guiVersionEl.textContent = data.version || 'unknown';
          guiVersionEl._loaded = true;
        })
        .catch(function () {
          guiVersionEl.textContent = 'unknown';
        });
    }

    if (baseVersionEl) {
      if (window.electronAPI && window.electronAPI.getPackageVersion) {
        // Electron mode: query the Python configured in Settings
        var pythonPath = (_settings && _settings.pythonPath) || 'python';
        window.electronAPI.getPackageVersion(pythonPath, 'MicroserviceBase')
          .then(function (ver) {
            baseVersionEl.textContent = ver;
          });
      } else {
        baseVersionEl.textContent = 'unknown';
      }
    }
  }

  function _wireHelpTOC() {
    var helpContent = document.getElementById('helpContent');
    if (!helpContent) return;

    // Close button
    var closeBtn = helpContent.querySelector('#docsCloseBtn');
    if (closeBtn) {
      closeBtn.addEventListener('click', function () { closeHelp(); });
    }

    // Smooth-scroll TOC links
    var tocLinks = helpContent.querySelectorAll('.docs-toc a[href^="#"]');
    var docsBody = helpContent.querySelector('#docsBody');

    tocLinks.forEach(function (link) {
      link.addEventListener('click', function (e) {
        e.preventDefault();
        var targetId = link.getAttribute('href').substring(1);
        var target = document.getElementById(targetId);
        if (target && docsBody) {
          var targetRect = target.getBoundingClientRect();
          var bodyRect = docsBody.getBoundingClientRect();
          docsBody.scrollTo({
            top: docsBody.scrollTop + (targetRect.top - bodyRect.top),
            behavior: 'smooth'
          });
        }
      });
    });

    // Scroll-spy: highlight active TOC link on scroll
    if (docsBody && tocLinks.length > 0) {
      var sections = helpContent.querySelectorAll('.docs-section[id]');
      docsBody.addEventListener('scroll', function () {
        var bodyRect = docsBody.getBoundingClientRect();
        var activeId = '';
        sections.forEach(function (sec) {
          var secRect = sec.getBoundingClientRect();
          if (secRect.top - bodyRect.top <= 40) {
            activeId = sec.id;
          }
        });
        tocLinks.forEach(function (link) {
          var isActive = link.getAttribute('href') === '#' + activeId;
          link.classList.toggle('active', isActive);
        });
      });
      // Trigger initial highlight
      tocLinks[0].classList.add('active');
    }

    // Click-to-zoom lightbox for images
    var docImages = helpContent.querySelectorAll('.docs-figure img');
    docImages.forEach(function (img) {
      img.addEventListener('click', function () {
        var overlay = document.createElement('div');
        overlay.className = 'docs-lightbox';
        var zoomed = document.createElement('img');
        zoomed.src = img.src;
        zoomed.alt = img.alt;
        overlay.appendChild(zoomed);
        overlay.addEventListener('click', function () {
          document.body.removeChild(overlay);
        });
        document.body.appendChild(overlay);
      });
    });
  }

  // Wire help button
  var btnHelp = document.getElementById('btnHelp');
  if (btnHelp) {
    btnHelp.addEventListener('click', function () { toggleHelp(); });
  }

  MM.toggleHelp = toggleHelp;
  MM.closeHelp = closeHelp;

  /************************************************************
   *               Settings Management                         *
   ************************************************************/

  var _settings = {};
  var settingsModal = null;

  function renderSettingsForm() {
    var body = document.getElementById('settingsModalBody');
    if (!body) return;

    body.innerHTML =
      '<form id="settingsForm">' +
        '<div class="mb-3">' +
          '<label for="settingPythonPath" class="form-label fw-semibold">Python Path</label>' +
          '<input type="text" class="form-control" id="settingPythonPath" ' +
            'placeholder="python" value="' + _escapeHtml(_settings.pythonPath || '') + '">' +
          '<div class="form-text">Path to Python interpreter (used by Electron to spawn the bridge)</div>' +
        '</div>' +

        '<hr>' +
        '<h6 class="fw-semibold mb-3">Service infrastructure</h6>' +
        '<div class="form-text mb-3 small">' +
          'Lookup priority for each binary: <strong>this setting</strong> &rarr; ' +
          '<code>PATH</code> &rarr; default install location ' +
          '(<code>%ProgramFiles%\\HashiCorp\\</code>). Leave empty to skip the ' +
          'override and let the bridge resolve via PATH.' +
        '</div>' +
        '<div class="mb-3">' +
          '<label for="settingConsulPath" class="form-label fw-semibold">Consul executable</label>' +
          '<div class="input-group">' +
            '<input type="text" class="form-control" id="settingConsulPath" ' +
              'placeholder="(auto-detect via PATH)" value="' +
              _escapeHtml(_settings.consulPath || '') + '">' +
            (window.electronAPI && window.electronAPI.showOpenDialog ?
              '<button class="btn btn-outline-secondary" type="button" id="btnBrowseConsulPath">' +
                '<i class="bi bi-folder2 me-1"></i>Browse&hellip;' +
              '</button>' : '') +
          '</div>' +
          '<div class="form-text">Used when starting the local Consul agent from the Service Network tab.</div>' +
        '</div>' +
        '<div class="mb-3">' +
          '<label for="settingNomadPath" class="form-label fw-semibold">Nomad executable</label>' +
          '<div class="input-group">' +
            '<input type="text" class="form-control" id="settingNomadPath" ' +
              'placeholder="(auto-detect via PATH)" value="' +
              _escapeHtml(_settings.nomadPath || '') + '">' +
            (window.electronAPI && window.electronAPI.showOpenDialog ?
              '<button class="btn btn-outline-secondary" type="button" id="btnBrowseNomadPath">' +
                '<i class="bi bi-folder2 me-1"></i>Browse&hellip;' +
              '</button>' : '') +
          '</div>' +
          '<div class="form-text">Used when starting the local Nomad agent from the Service Network tab.</div>' +
        '</div>' +

        '<hr>' +
        '<h6 class="fw-semibold mb-3">Bridge &amp; broker</h6>' +
        '<div class="row mb-3">' +
          '<div class="col">' +
            '<label for="settingBrokerHost" class="form-label fw-semibold">Broker Host</label>' +
            '<input type="text" class="form-control" id="settingBrokerHost" ' +
              'placeholder="localhost" value="' + _escapeHtml(_settings.brokerHost || '') + '">' +
          '</div>' +
          '<div class="col">' +
            '<label for="settingBrokerPort" class="form-label fw-semibold">Broker Port</label>' +
            '<input type="text" class="form-control" id="settingBrokerPort" ' +
              'placeholder="5672" value="' + _escapeHtml(_settings.brokerPort || '') + '">' +
          '</div>' +
        '</div>' +
        '<div class="mb-3">' +
          '<label for="settingBridgePort" class="form-label fw-semibold">Bridge Port</label>' +
          '<input type="number" class="form-control" id="settingBridgePort" ' +
            'placeholder="1112" value="' + _escapeHtml(_settings.bridgePort || '') + '">' +
          '<div class="form-text">Port for the FastAPI bridge (REST API &amp; WebSocket)</div>' +
        '</div>' +
      '</form>';

    _wireSettingsBrowseButtons();
  }

  // Wire the optional Browse buttons next to Consul/Nomad path inputs.
  // Only present in Electron — plain browsers can't open the OS file
  // picker (an <input type="file"> would work but the browser redacts
  // the absolute path on submit, which is exactly what we need).
  function _wireSettingsBrowseButtons() {
    if (!window.electronAPI || !window.electronAPI.showOpenDialog) return;

    function _pickExecutable(forTool, inputId) {
      var binName = forTool === 'consul' ? 'consul.exe' : 'nomad.exe';
      window.electronAPI.showOpenDialog({
        properties: ['openFile'],
        title: 'Locate the ' + forTool + ' executable',
        filters: [
          { name: forTool + ' executable', extensions: ['exe'] },
          { name: 'All files',             extensions: ['*'] }
        ],
        defaultPath: binName
      }).then(function (result) {
        if (!result || result.canceled) return;
        var picked = result.filePaths && result.filePaths[0];
        if (!picked) return;
        var input = document.getElementById(inputId);
        if (input) input.value = picked;
      }).catch(function (err) {
        console.error('[settings] Browse dialog failed:', err);
      });
    }

    var consulBtn = document.getElementById('btnBrowseConsulPath');
    if (consulBtn) {
      consulBtn.addEventListener('click', function () {
        _pickExecutable('consul', 'settingConsulPath');
      });
    }
    var nomadBtn = document.getElementById('btnBrowseNomadPath');
    if (nomadBtn) {
      nomadBtn.addEventListener('click', function () {
        _pickExecutable('nomad', 'settingNomadPath');
      });
    }
  }

  function openSettings() {
    renderSettingsForm();
    if (!settingsModal) {
      settingsModal = new bootstrap.Modal(document.getElementById('settingsModal'));
    }
    settingsModal.show();
  }

  function saveSettings() {
    var pythonPathInput = document.getElementById('settingPythonPath');
    var consulPathInput = document.getElementById('settingConsulPath');
    var nomadPathInput  = document.getElementById('settingNomadPath');
    var brokerHostInput = document.getElementById('settingBrokerHost');
    var brokerPortInput = document.getElementById('settingBrokerPort');
    var bridgePortInput = document.getElementById('settingBridgePort');
    var newSettings = {
      pythonPath: pythonPathInput ? pythonPathInput.value.trim() : '',
      consulPath: consulPathInput ? consulPathInput.value.trim() : '',
      nomadPath:  nomadPathInput  ? nomadPathInput.value.trim()  : '',
      brokerHost: brokerHostInput ? brokerHostInput.value.trim() : '',
      brokerPort: brokerPortInput ? brokerPortInput.value.trim() : '',
      bridgePort: bridgePortInput ? bridgePortInput.value.trim() : ''
    };

    _settings = Object.assign(_settings, newSettings);

    if (window.electronAPI && window.electronAPI.saveSettings) {
      window.electronAPI.saveSettings(_settings)
        .then(function () {
          showToast('Settings', 'Settings saved.', 'success');
        })
        .catch(function (err) {
          showToast('Error', 'Failed to save settings: ' + err.message, 'danger');
        });
    } else {
      try {
        sessionStorage.setItem('mm_settings', JSON.stringify(_settings));
        showToast('Settings', 'Settings saved.', 'success');
      } catch (e) {
        showToast('Error', 'Failed to save settings.', 'danger');
      }
    }

    if (settingsModal) settingsModal.hide();
  }

  function _fetchBaseVersion() {
    if (window.electronAPI && window.electronAPI.getPackageVersion) {
      var pyPath = (_settings && _settings.pythonPath) || 'python';
      window.electronAPI.getPackageVersion(pyPath, 'MicroserviceBase')
        .then(function (ver) { MM._baseVersion = ver; })
        .catch(function () {});
    } else if (MM.serviceClient && MM.serviceClient.apiUrl) {
      fetch(MM.serviceClient.apiUrl + '/api/version')
        .then(function (res) { return res.json(); })
        .then(function (data) {
          if (data && data.version) {
            MM._baseVersion = data.version;
          }
        })
        .catch(function () {});
    }
  }

  function loadSettings() {
    if (window.electronAPI && window.electronAPI.loadSettings) {
      window.electronAPI.loadSettings()
        .then(function (settings) {
          _settings = settings || {};
          console.log('[app] Settings loaded from file:', Object.keys(_settings));
          _fetchBaseVersion();
        })
        .catch(function () {
          _settings = {};
          _fetchBaseVersion();
        });
    } else {
      try {
        var raw = sessionStorage.getItem('mm_settings');
        if (raw) {
          _settings = JSON.parse(raw);
          console.log('[app] Settings loaded from sessionStorage:', Object.keys(_settings));
        }
      } catch (e) {
        _settings = {};
      }
      _fetchBaseVersion();
    }
  }

  // Wire settings button and save button
  var btnSettings = document.getElementById('btnSettings');
  if (btnSettings) {
    btnSettings.addEventListener('click', function () {
      openSettings();
    });
  }

  var btnSettingsSave = document.getElementById('btnSettingsSave');
  if (btnSettingsSave) {
    btnSettingsSave.addEventListener('click', function () {
      saveSettings();
    });
  }

  // Load settings on startup
  loadSettings();

  // Expose getSettings for other modules (e.g., LocalHubDashboard)
  MM.getSettings = function () { return _settings; };

  /************************************************************
   *               Report Issue                                 *
   ************************************************************/

  var reportIssueModal = null;
  var GITHUB_ISSUES_URL = 'https://github.com/test-fullautomation/python-microservice-base/issues/new';

  /**
   * Open a URL in the default browser (Electron) or a new tab (browser mode).
   */
  function _openUrl(url) {
    if (window.electronAPI && window.electronAPI.openExternal) {
      window.electronAPI.openExternal(url);
    } else {
      window.open(url, '_blank', 'noopener');
    }
  }

  /**
   * Collect environment info as a markdown string for the issue body.
   */
  function _collectEnvironmentInfo() {
    var lines = [];

    lines.push('## Environment');

    // GUI version — prefer eagerly-cached value, fall back to help page element
    var guiVersion = MM._guiVersion || 'unknown';
    if (guiVersion === 'unknown') {
      var guiVersionEl = document.querySelector('#docsGuiVersion');
      if (guiVersionEl && guiVersionEl.textContent && guiVersionEl.textContent !== 'loading...') {
        guiVersion = guiVersionEl.textContent;
      }
    }
    lines.push('- **GUI Version**: ' + guiVersion);

    // MicroserviceBase version
    var baseVersion = MM._baseVersion || 'unknown';
    lines.push('- **MicroserviceBase Version**: ' + baseVersion);

    // Platform
    lines.push('- **Platform**: ' + navigator.platform);
    lines.push('- **User Agent**: ' + navigator.userAgent);

    // Connected brokers
    var brokerKeys = Object.keys(MM.connections || {});
    if (brokerKeys.length > 0) {
      lines.push('- **Connected Brokers**: ' + brokerKeys.join(', '));
    } else {
      lines.push('- **Connected Brokers**: none');
    }

    // Services count
    var serviceCount = MM.servicesInfor ? Object.keys(MM.servicesInfor).length : 0;
    lines.push('- **Services**: ' + serviceCount + ' loaded');

    return lines.join('\n');
  }

  function openReportIssue() {
    // Clear previous input
    var titleInput = document.getElementById('issueTitle');
    var bodyInput = document.getElementById('issueBody');
    if (titleInput) titleInput.value = '';
    if (bodyInput) bodyInput.value = '';

    if (!reportIssueModal) {
      reportIssueModal = new bootstrap.Modal(document.getElementById('reportIssueModal'));
    }
    reportIssueModal.show();
  }

  function submitReportIssue() {
    var titleInput = document.getElementById('issueTitle');
    var bodyInput = document.getElementById('issueBody');

    var title = titleInput ? titleInput.value.trim() : '';
    if (!title) {
      showToast('Validation', 'Please provide a summary for the issue.', 'warning');
      titleInput.focus();
      return;
    }

    var userBody = bodyInput ? bodyInput.value.trim() : '';
    var envInfo = _collectEnvironmentInfo();

    var bodyParts = ['## Description'];
    if (userBody) {
      bodyParts.push(userBody);
    } else {
      bodyParts.push('_No additional details provided._');
    }
    bodyParts.push('');
    bodyParts.push(envInfo);

    var body = bodyParts.join('\n');

    var url = GITHUB_ISSUES_URL + '?title=' + encodeURIComponent(title) + '&body=' + encodeURIComponent(body);

    // URL length safety: browsers/GitHub typically support ~8000 chars
    var MAX_URL_LENGTH = 7500;
    if (url.length > MAX_URL_LENGTH) {
      var truncatedNote = '\n\n_(Details truncated due to URL length limits. Please add remaining details manually.)_';
      var availableBodyLength = MAX_URL_LENGTH
        - (GITHUB_ISSUES_URL + '?title=' + encodeURIComponent(title) + '&body=').length;
      // Decode, truncate, re-encode
      var truncatedBody = body.substring(0, Math.max(100, availableBodyLength / 3)) + truncatedNote;
      url = GITHUB_ISSUES_URL + '?title=' + encodeURIComponent(title) + '&body=' + encodeURIComponent(truncatedBody);
    }

    _openUrl(url);

    if (reportIssueModal) reportIssueModal.hide();
    showToast('Report Issue', 'Issue page opened in your browser.', 'success');
  }

  // Wire Report Issue button
  var btnReportIssue = document.getElementById('btnReportIssue');
  if (btnReportIssue) {
    btnReportIssue.addEventListener('click', function () {
      openReportIssue();
    });
  }

  // Wire submit button
  var btnSubmitIssue = document.getElementById('btnSubmitIssue');
  if (btnSubmitIssue) {
    btnSubmitIssue.addEventListener('click', function () {
      submitReportIssue();
    });
  }

  // Eagerly fetch versions so env info is available even if help was never opened
  fetch('version.json')
    .then(function (res) { return res.json(); })
    .then(function (data) {
      if (data && data.version) {
        MM._guiVersion = data.version;
      }
    })
    .catch(function () {});

  // App initialization complete — hide loading overlay
  var _loadingOverlay = document.getElementById('loadingOverlay');
  if (_loadingOverlay) _loadingOverlay.classList.remove('active');

})();
