/**
 * GUI for SampleService service.
 */
(function () {
  'use strict';

  var MM = window.MicroserviceManager;

  function loadSampleService() {
    console.log('SampleService GUI loaded');
  }

  function unloadSampleService() {
    console.log('SampleService GUI unloaded');
  }

  // Expose load/unload to global scope for the service loader
  window.loadSampleService = loadSampleService;
  window.unloadSampleService = unloadSampleService;

  // Initial load
  loadSampleService();
})();
